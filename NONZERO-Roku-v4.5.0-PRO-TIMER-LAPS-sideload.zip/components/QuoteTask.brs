sub init()
    m.top.functionName = "runQuoteRequest"
end sub

sub runQuoteRequest()
    endpoint = m.top.endpoint
    if endpoint = invalid or endpoint = "" then m.top.error = "No quote service" : return
    if right(endpoint, 1) = "/" then endpoint = left(endpoint, len(endpoint)-1)
    deviceId = m.top.deviceId
    if deviceId = invalid or len(deviceId) < 6 then m.top.error = "No device id" : return

    transfer = CreateObject("roUrlTransfer")
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()
    transfer.AddHeader("Accept", "application/json")

    if m.top.mode = "feedback" then
        transfer.SetUrl(endpoint + "/quotes/feedback")
        transfer.AddHeader("Content-Type", "application/json")
        text = transfer.PostFromString(FormatJson({device:deviceId, id:m.top.quoteId, action:m.top.action}))
    else
        transfer.SetUrl(endpoint + "/quotes/feed?device=" + deviceId + "&limit=100")
        text = transfer.GetToString()
    end if
    if text = invalid or text = "" then m.top.error = "Quote cloud unavailable" : return
    data = ParseJson(text)
    if data = invalid then m.top.error = "Invalid quote response" : return
    if data.error <> invalid then m.top.error = data.error : return
    m.top.result = data
end sub
