sub init()
    m.top.functionName = "claimPair"
end sub

sub claimPair()
    if m.top.endpoint = invalid or m.top.endpoint = "" then
        m.top.error = "Pairing service unavailable"
        return
    end if
    code = m.top.code
    if code = invalid or len(code) <> 6 then
        m.top.error = "Enter a 6-digit code"
        return
    end if
    url = m.top.endpoint
    if right(url, 1) = "/" then url = left(url, len(url) - 1)
    transfer = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    transfer.SetMessagePort(port)
    transfer.SetUrl(url + "/pair/claim")
    transfer.AddHeader("Content-Type", "application/json")
    transfer.AddHeader("Accept", "application/json")
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()
    body = FormatJson({ code: code })
    ok = transfer.AsyncPostFromString(body)
    if not ok then
        m.top.error = "Could not start pairing request"
        return
    end if
    msg = wait(6500, port)
    if msg = invalid then
        transfer.AsyncCancel()
        m.top.error = "Pairing timed out"
        return
    end if
    if type(msg) <> "roUrlEvent" then
        m.top.error = "Pairing failed"
        return
    end if
    status = msg.GetResponseCode()
    text = msg.GetString()
    if text = invalid or text = "" then
        m.top.error = "Could not reach pairing service"
        return
    end if
    data = ParseJson(text)
    if data = invalid then
        m.top.error = "Invalid pairing response"
        return
    end if
    if status < 200 or status >= 300 or data.wallToken = invalid or data.wallToken = "" then
        if data.error <> invalid and data.error = "pair_code_expired_or_invalid" then
            m.top.error = "Code expired or invalid"
        else
            m.top.error = "Pairing failed"
        end if
        return
    end if
    m.top.result = data
end sub
