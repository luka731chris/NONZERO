sub init()
    m.top.functionName = "fetchState"
end sub

sub fetchState()
    if m.top.endpoint = invalid or m.top.endpoint = "" or m.top.wallToken = invalid or m.top.wallToken = "" then
        m.top.error = "Not paired"
        return
    end if

    url = m.top.endpoint
    if right(url, 1) = "/" then url = left(url, len(url) - 1)
    transfer = CreateObject("roUrlTransfer")
    transfer.SetUrl(url + "/state")
    transfer.AddHeader("X-NONZERO-Wall", m.top.wallToken)
    transfer.AddHeader("Accept", "application/json")
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()

    text = transfer.GetToString()
    if text = invalid or text = "" then
        m.top.error = "Cloud unavailable"
        return
    end if
    data = ParseJson(text)
    if data = invalid then
        m.top.error = "Invalid cloud response"
        return
    end if
    if data.error <> invalid then
        if data.error = "missing_or_invalid_key" then
            m.top.error = "Pairing expired · press *"
        else
            m.top.error = "Cloud error"
        end if
        return
    end if
    if data.state = invalid then
        m.top.error = "Phone synced · no state yet"
        return
    end if
    m.top.result = data
end sub
