sub Main()
    showNonzeroWall(false)
end sub

sub RunScreenSaver()
    showNonzeroWall(true)
end sub

sub showNonzeroWall(isScreensaver as Boolean)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    scene = screen.CreateScene("NonzeroWallScene")
    scene.isScreensaver = isScreensaver
    scene.observeField("quoteAction", port)
    screen.Show()

    clockNode = scene.findNode("clock")
    dateNode = scene.findNode("date")
    quoteNode = scene.findNode("ambientQuote")
    quoteAuthorNode = scene.findNode("ambientQuoteAuthor")
    quoteNodeB = scene.findNode("ambientQuoteB")
    quoteAuthorNodeB = scene.findNode("ambientQuoteAuthorB")
    quoteLayerA = scene.findNode("quoteLayerA")
    quoteLayerB = scene.findNode("quoteLayerB")
    quoteFadeAOut = scene.findNode("quoteFadeAOut")
    quoteFadeAIn = scene.findNode("quoteFadeAIn")
    quoteFadeBOut = scene.findNode("quoteFadeBOut")
    quoteFadeBIn = scene.findNode("quoteFadeBIn")
    cloudNode = scene.findNode("cloudStatus")

    quotes = buildQuoteLibrary()
    pref = CreateObject("roRegistrySection", "NONZERO_QUOTES_V2")
    seedClock = CreateObject("roDateTime")
    qSeed = seedClock.AsSeconds() mod 65536
    rotationCount = readInt(pref, "rotationCount", 0)
    qIndex = chooseQuote(quotes, pref, qSeed, rotationCount, -1, [], [], [])
    activeQuoteLayer = 0
    recentIds = []
    recentAuthors = []
    recentDomains = []
    elapsed = 0
    forceRotate = false

    updateAmbientClock(clockNode, dateNode)
    scene.heartbeat = 1
    setInitialQuote(quotes[qIndex], quoteNode, quoteAuthorNode, quoteLayerA, quoteLayerB)
    recordExposure(pref, quotes[qIndex])
    pushRecent(recentIds, quotes[qIndex].id, 18)
    pushRecent(recentAuthors, quotes[qIndex].author, 7)
    pushRecent(recentDomains, quotes[qIndex].domain, 7)

    if cloudNode <> invalid and cloudNode.text = "● CONNECTING" then cloudNode.text = "● LOCAL LIVE"

    while true
        msg = wait(1000, port)
        if type(msg) = "roSGScreenEvent" and msg.isScreenClosed() then return

        if type(msg) = "roSGNodeEvent" then
            if msg.GetField() = "quoteAction" then
                action = msg.GetData()
                if action = "more" or action = "less" then
                    applyQuoteFeedback(pref, quotes[qIndex], action)
                    forceRotate = true
                else if action = "next" then
                    forceRotate = true
                end if
            end if
        end if

        elapsed = elapsed + 1
        updateAmbientClock(clockNode, dateNode)
        scene.heartbeat = elapsed

        if forceRotate or elapsed mod 16 = 0 then
            forceRotate = false
            qSeed = (qSeed * 25173 + 13849) mod 65536
            rotationCount = rotationCount + 1
            pref.Write("rotationCount", rotationCount.toStr())
            pref.Flush()

            nextIndex = chooseQuote(quotes, pref, qSeed, rotationCount, qIndex, recentIds, recentAuthors, recentDomains)
            qIndex = nextIndex
            q = quotes[qIndex]
            recordExposure(pref, q)
            pushRecent(recentIds, q.id, 18)
            pushRecent(recentAuthors, q.author, 7)
            pushRecent(recentDomains, q.domain, 7)

            if activeQuoteLayer = 0 then
                if quoteNodeB <> invalid then quoteNodeB.text = q.text
                if quoteAuthorNodeB <> invalid then quoteAuthorNodeB.uri = "pkg:/images/authors/" + q.asset + ".png"
                if quoteLayerB <> invalid then quoteLayerB.opacity = 0
                if quoteFadeAOut <> invalid then quoteFadeAOut.control = "start"
                if quoteFadeBIn <> invalid then quoteFadeBIn.control = "start"
                activeQuoteLayer = 1
            else
                if quoteNode <> invalid then quoteNode.text = q.text
                if quoteAuthorNode <> invalid then quoteAuthorNode.uri = "pkg:/images/authors/" + q.asset + ".png"
                if quoteLayerA <> invalid then quoteLayerA.opacity = 0
                if quoteFadeBOut <> invalid then quoteFadeBOut.control = "start"
                if quoteFadeAIn <> invalid then quoteFadeAIn.control = "start"
                activeQuoteLayer = 0
            end if
        end if
    end while
end sub

function buildQuoteLibrary() as Object
    return [
        {id:"goggins_done", text:"DON'T STOP WHEN YOU'RE TIRED. STOP WHEN YOU'RE DONE.", author:"David Goggins", asset:"david-goggins", domain:"ENDURANCE", tier:3, source:3, tags:["discipline","endurance","execution","resilience"]},
        {id:"jocko_def", text:"DISCIPLINE EQUALS FREEDOM.", author:"Jocko Willink", asset:"jocko-willink", domain:"MILITARY", tier:3, source:3, tags:["discipline","ownership","execution"]},
        {id:"jocko_excuses", text:"STOP. MAKING. EXCUSES. TAKE ACTION. OWN YOUR DECISIONS. EXECUTE.", author:"Jocko Willink", asset:"jocko-willink", domain:"MILITARY", tier:3, source:3, tags:["ownership","execution","discipline"]},
        {id:"mcraven_bed", text:"IF YOU WANT TO CHANGE THE WORLD, START OFF BY MAKING YOUR BED.", author:"Adm. William McRaven", asset:"admiral-william-mcraven", domain:"MILITARY", tier:3, source:3, tags:["discipline","standards","momentum"]},
        {id:"mcraven_little", text:"IF YOU CAN'T DO THE LITTLE THINGS RIGHT, YOU WILL NEVER DO THE BIG THINGS RIGHT.", author:"Adm. William McRaven", asset:"admiral-william-mcraven", domain:"MILITARY", tier:3, source:3, tags:["standards","details","discipline"]},
        {id:"powell_optimism", text:"PERPETUAL OPTIMISM IS A FORCE MULTIPLIER.", author:"Colin Powell", asset:"colin-powell", domain:"LEADERSHIP", tier:3, source:3, tags:["optimism","leadership","resilience"]},
        {id:"eisenhower_planning", text:"PLANS ARE WORTHLESS, BUT PLANNING IS EVERYTHING.", author:"Dwight Eisenhower", asset:"dwight-eisenhower", domain:"PRESIDENTIAL", tier:3, source:3, tags:["preparation","adaptability","leadership"]},
        {id:"fdr_fear", text:"THE ONLY THING WE HAVE TO FEAR IS FEAR ITSELF.", author:"Franklin D. Roosevelt", asset:"franklin-d-roosevelt", domain:"PRESIDENTIAL", tier:3, source:3, tags:["courage","composure","resilience"]},
        {id:"reagan_verify", text:"TRUST, BUT VERIFY.", author:"Ronald Reagan", asset:"ronald-reagan", domain:"PRESIDENTIAL", tier:3, source:3, tags:["judgment","standards","leadership"]},
        {id:"tr_arena", text:"THE CREDIT BELONGS TO THE MAN WHO IS ACTUALLY IN THE ARENA.", author:"Theodore Roosevelt", asset:"theodore-roosevelt", domain:"PRESIDENTIAL", tier:3, source:3, tags:["courage","action","resilience"]},
        {id:"tomlin_standard", text:"THE STANDARD IS THE STANDARD.", author:"Mike Tomlin", asset:"mike-tomlin", domain:"SPORTS", tier:3, source:3, tags:["standards","consistency","execution"]},
        {id:"tomlin_opportunity", text:"I DON'T WORRY ABOUT THE LIMITS. I JUST WORK WITH THE OPPORTUNITY GIVEN.", author:"Mike Tomlin", asset:"mike-tomlin", domain:"SPORTS", tier:3, source:3, tags:["adaptability","execution","focus"]},
        {id:"cowher_mindset", text:"RE-ESTABLISH THE MIND-SET.", author:"Bill Cowher", asset:"bill-cowher", domain:"SPORTS", tier:3, source:3, tags:["mindset","intensity","standards"]},
        {id:"brady_confidence", text:"CONFIDENCE DOES COME FROM PREPARATION AND SOLID PREPARATION IN PRACTICE.", author:"Tom Brady", asset:"tom-brady", domain:"SPORTS", tier:3, source:3, tags:["preparation","confidence","practice"]},
        {id:"brady_outprepare", text:"WE'RE GOING TO TRY TO OUT-PREPARE THEM THIS WEEK.", author:"Tom Brady", asset:"tom-brady", domain:"SPORTS", tier:3, source:3, tags:["preparation","competition","execution"]},
        {id:"loehr_energy", text:"ENERGY, NOT TIME, IS THE FUNDAMENTAL CURRENCY OF HIGH PERFORMANCE.", author:"Jim Loehr", asset:"jim-loehr", domain:"PSYCHOLOGY", tier:3, source:2, tags:["energy","performance","recovery"]},
        {id:"gervais_train", text:"THERE ARE ONLY THREE THINGS WE CAN TRAIN: OUR CRAFT, OUR BODY, AND OUR MIND.", author:"Michael Gervais", asset:"michael-gervais", domain:"PSYCHOLOGY", tier:3, source:2, tags:["mindset","practice","performance"]},
        {id:"belichick_job", text:"EACH OF US HAS A JOB TO DO.", author:"Bill Belichick", asset:"bill-belichick", domain:"SPORTS", tier:2, source:3, tags:["execution","role","team"]},
        {id:"belichick_prepare", text:"PLAYERS' ROLES CHANGE EVERY WEEK.", author:"Bill Belichick", asset:"bill-belichick", domain:"SPORTS", tier:2, source:3, tags:["adaptability","preparation","team"]},
        {id:"kranz_tough", text:"TOUGH AND COMPETENT.", author:"Gene Kranz", asset:"gene-kranz", domain:"SPACE", tier:2, source:3, tags:["standards","competence","resilience"]},
        {id:"kranz_risk", text:"THERE IS NO ACHIEVEMENT WITHOUT RISK.", author:"Gene Kranz", asset:"gene-kranz", domain:"SPACE", tier:2, source:3, tags:["courage","risk","achievement"]},
        {id:"jobs_time", text:"YOUR TIME IS LIMITED, SO DON'T WASTE IT LIVING SOMEONE ELSE'S LIFE.", author:"Steve Jobs", asset:"steve-jobs", domain:"BUSINESS", tier:2, source:3, tags:["focus","purpose","courage"]},
        {id:"wooden_effort", text:"SUCCESS IS MAKING THE EFFORT TO DO THE BEST YOU CAN DO.", author:"John Wooden", asset:"john-wooden", domain:"SPORTS", tier:2, source:3, tags:["effort","standards","consistency"]},
        {id:"wooden_discipline", text:"DISCIPLINE YOURSELF AND OTHERS WON'T NEED TO.", author:"John Wooden", asset:"john-wooden", domain:"SPORTS", tier:2, source:3, tags:["discipline","ownership","leadership"]},
        {id:"saban_focus", text:"FOCUS ON THE THINGS THAT MATTER.", author:"Nick Saban", asset:"nick-saban", domain:"SPORTS", tier:2, source:3, tags:["focus","preparation","details"]},
        {id:"saban_action", text:"ACCOMPLISHMENT IS ALL ABOUT ACTION.", author:"Nick Saban", asset:"nick-saban", domain:"SPORTS", tier:2, source:3, tags:["action","execution","achievement"]},
        {id:"summitt_attitude", text:"ATTITUDE IS A CHOICE.", author:"Pat Summitt", asset:"pat-summitt", domain:"SPORTS", tier:2, source:3, tags:["mindset","ownership","resilience"]},
        {id:"summitt_confidence", text:"CONFIDENCE IS WHAT HAPPENS WHEN YOU'VE DONE THE HARD WORK THAT ENTITLES YOU TO SUCCEED.", author:"Pat Summitt", asset:"pat-summitt", domain:"SPORTS", tier:2, source:3, tags:["confidence","preparation","work"]},
        {id:"duckworth_grit", text:"GRIT IS LIVING LIKE LIFE'S A MARATHON, NOT A SPRINT.", author:"Angela Duckworth", asset:"angela-duckworth", domain:"PSYCHOLOGY", tier:2, source:3, tags:["grit","endurance","consistency"]},
        {id:"luttrell_neverquit", text:"NEVER QUIT.", author:"Marcus Luttrell", asset:"marcus-luttrell", domain:"MILITARY", tier:2, source:3, tags:["resilience","endurance","courage"]},
        {id:"seal_ethos", text:"I WILL NEVER QUIT. I WILL PERSEVERE AND THRIVE ON ADVERSITY.", author:"U.S. Navy SEAL Ethos", asset:"us-navy-seal-ethos", domain:"MILITARY", tier:2, source:2, tags:["resilience","adversity","team"]},
        {id:"nadella_learn", text:"DON'T BE A KNOW-IT-ALL; BE A LEARN-IT-ALL.", author:"Satya Nadella", asset:"satya-nadella", domain:"BUSINESS", tier:1, source:3, tags:["learning","humility","growth"]},
        {id:"buffett_reputation", text:"WE CAN'T AFFORD TO LOSE REPUTATION — EVEN A SHRED OF REPUTATION.", author:"Warren Buffett", asset:"warren-buffett", domain:"BUSINESS", tier:1, source:3, tags:["integrity","standards","judgment"]},
        {id:"branson_failure", text:"I TRY TO SEE FAILURE AS A LEARNING OPPORTUNITY.", author:"Richard Branson", asset:"richard-branson", domain:"BUSINESS", tier:1, source:3, tags:["learning","risk","resilience"]},
        {id:"bezos_invent", text:"WE INVENT BEFORE WE HAVE TO.", author:"Jeff Bezos", asset:"jeff-bezos", domain:"BUSINESS", tier:1, source:3, tags:["innovation","initiative","standards"]},
        {id:"nonzero_zero", text:"ZERO IS THE ONLY MISS.", author:"NONZERO", asset:"nonzero-nonzero", domain:"NONZERO", tier:0, source:0, tags:["consistency","action"]},
        {id:"nonzero_ten", text:"TEN MINUTES BEATS ZERO.", author:"NONZERO", asset:"nonzero-nonzero", domain:"NONZERO", tier:0, source:0, tags:["consistency","momentum"]},
        {id:"nonzero_board", text:"SHOW UP. PUT A NUMBER ON THE BOARD.", author:"NONZERO", asset:"nonzero-nonzero", domain:"NONZERO", tier:0, source:0, tags:["action","consistency"]},
        {id:"nonzero_identity", text:"MAKE CONSISTENCY THE IDENTITY AND INTENSITY THE VARIABLE.", author:"NONZERO", asset:"nonzero-behavior", domain:"NONZERO", tier:0, source:0, tags:["consistency","identity","adaptability"]},
        {id:"nonzero_shrink", text:"WHEN RESISTANCE IS HIGH, SHRINK THE TASK INSTEAD OF DELETING IT.", author:"NONZERO", asset:"nonzero-behavior", domain:"NONZERO", tier:0, source:0, tags:["momentum","adaptability","resilience"]},
        {id:"nonzero_evidence", text:"YOUR FUTURE SELF NEEDS EVIDENCE, NOT ANOTHER INTENTION.", author:"NONZERO", asset:"nonzero-behavior", domain:"NONZERO", tier:0, source:0, tags:["action","identity","execution"]}
    ]
end function

function chooseQuote(quotes as Object, pref as Object, seed as Integer, rotationCount as Integer, currentIndex as Integer, recentIds as Object, recentAuthors as Object, recentDomains as Object) as Integer
    ' 90% real voices, 10% NONZERO brand voice. Within real voices, use an
    ' Amazon-style explore/exploit mix: 55% anchors, 30% adjacent, 15% discovery.
    if rotationCount > 0 and rotationCount mod 10 = 0 then targetTier = 0 else targetTier = -1
    if targetTier <> 0 then
        bucket = seed mod 20
        if bucket < 11 then
            targetTier = 3
        else if bucket < 17 then
            targetTier = 2
        else
            targetTier = 1
        end if
    end if

    bestIndex = -1
    bestScore = -99999
    for i = 0 to quotes.count() - 1
        q = quotes[i]
        if q.tier = targetTier then
            s = scoreQuote(q, pref, seed, i, recentIds, recentAuthors, recentDomains)
            if i = currentIndex then s = s - 1000
            if s > bestScore then
                bestScore = s
                bestIndex = i
            end if
        end if
    end for

    if bestIndex >= 0 then return bestIndex
    for i = 0 to quotes.count() - 1
        if i <> currentIndex then return i
    end for
    return 0
end function

function scoreQuote(q as Object, pref as Object, seed as Integer, index as Integer, recentIds as Object, recentAuthors as Object, recentDomains as Object) as Integer
    score = 100 + (q.source * 7)
    score = score + (domainWeight(pref, q.domain) * 9)
    score = score + (authorWeight(pref, q.author, q.tier) * 10)
    for each tag in q.tags
        score = score + (tagWeight(pref, tag) * 8)
    end for

    exposure = readInt(pref, "exp_" + q.id, 0)
    if exposure > 12 then exposure = 12
    score = score - (exposure * 3)

    if containsText(recentIds, q.id) then score = score - 300
    if containsText(recentAuthors, q.author) then score = score - 90
    if recentDomains.count() >= 2 then
        if recentDomains[recentDomains.count()-1] = q.domain and recentDomains[recentDomains.count()-2] = q.domain then score = score - 70
    end if

    ' Small deterministic jitter prevents the same highest-score quote from always
    ' winning while preserving the taste profile as the dominant signal.
    score = score + ((seed + index * 37) mod 19)
    return score
end function

sub applyQuoteFeedback(pref as Object, q as Object, action as String)
    delta = 1
    if action = "less" then delta = -1
    changeWeight(pref, "author_" + safeKey(q.author), delta * 2, -8, 12)
    changeWeight(pref, "domain_" + safeKey(q.domain), delta, -6, 10)
    for each tag in q.tags
        changeWeight(pref, "tag_" + safeKey(tag), delta, -6, 10)
    end for
    if q.tier = 1 then changeWeight(pref, "discoveryAffinity", delta, -5, 8)
    pref.Flush()
end sub

sub recordExposure(pref as Object, q as Object)
    k = "exp_" + q.id
    n = readInt(pref, k, 0) + 1
    if n > 99 then n = 99
    pref.Write(k, n.toStr())
    pref.Flush()
end sub

function tagWeight(pref as Object, tag as String) as Integer
    k = "tag_" + safeKey(tag)
    stored = pref.Read(k)
    if stored <> invalid and stored <> "" then return int(val(stored))
    defaults = {discipline:5, execution:5, preparation:5, standards:5, resilience:5, focus:5, ownership:4, courage:4, consistency:4, mindset:4, confidence:3, leadership:3, recovery:2, learning:2, adaptability:3, team:2, risk:2, innovation:2, integrity:3, action:5, momentum:4, endurance:4, details:3, competence:3, optimism:2, judgment:3, growth:2, effort:3, practice:4, grit:4, adversity:4, work:3, achievement:3, initiative:3, humility:2, purpose:3, identity:3, role:2, energy:2, performance:4, competition:3}
    if defaults[tag] <> invalid then return defaults[tag]
    return 1
end function

function domainWeight(pref as Object, domain as String) as Integer
    k = "domain_" + safeKey(domain)
    stored = pref.Read(k)
    if stored <> invalid and stored <> "" then return int(val(stored))
    defaults = {MILITARY:5, SPORTS:5, PSYCHOLOGY:4, LEADERSHIP:4, PRESIDENTIAL:3, SPACE:3, BUSINESS:3, ENDURANCE:5, NONZERO:2}
    if defaults[domain] <> invalid then return defaults[domain]
    return 1
end function

function authorWeight(pref as Object, author as String, tier as Integer) as Integer
    k = "author_" + safeKey(author)
    stored = pref.Read(k)
    if stored <> invalid and stored <> "" then return int(val(stored))
    if tier = 3 then return 3
    if tier = 2 then return 1
    return 0
end function

sub changeWeight(pref as Object, key as String, delta as Integer, low as Integer, high as Integer)
    n = readInt(pref, key, 0) + delta
    if n < low then n = low
    if n > high then n = high
    pref.Write(key, n.toStr())
end sub

function readInt(pref as Object, key as String, fallback as Integer) as Integer
    v = pref.Read(key)
    if v = invalid or v = "" then return fallback
    return int(val(v))
end function

function safeKey(s as String) as String
    src = LCase(s)
    out = ""
    for i = 1 to len(src)
        c = mid(src, i, 1)
        if (c >= "a" and c <= "z") or (c >= "0" and c <= "9") then
            out = out + c
        else if c = " " or c = "-" then
            out = out + "_"
        end if
    end for
    return out
end function

function containsText(items as Object, value as String) as Boolean
    for each item in items
        if item = value then return true
    end for
    return false
end function

sub pushRecent(items as Object, value as String, maxCount as Integer)
    items.push(value)
    while items.count() > maxCount
        items.shift()
    end while
end sub

sub setInitialQuote(q as Object, quoteNode as Object, authorNode as Object, layerA as Object, layerB as Object)
    if quoteNode <> invalid then quoteNode.text = q.text
    if authorNode <> invalid then authorNode.uri = "pkg:/images/authors/" + q.asset + ".png"
    if layerA <> invalid then layerA.opacity = 1
    if layerB <> invalid then layerB.opacity = 0
end sub

sub updateAmbientClock(clockNode as Object, dateNode as Object)
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    h = dt.GetHours()
    mins = dt.GetMinutes()
    suffix = "AM"
    displayH = h
    if h >= 12 then suffix = "PM"
    if displayH = 0 then displayH = 12
    if displayH > 12 then displayH = displayH - 12
    mm = mins.toStr()
    if mins < 10 then mm = "0" + mm
    if clockNode <> invalid then clockNode.text = displayH.toStr() + ":" + mm + " " + suffix
    if dateNode <> invalid then dateNode.text = dt.GetMonth().toStr() + "/" + dt.GetDayOfMonth().toStr() + "/" + dt.GetYear().toStr()
end sub
