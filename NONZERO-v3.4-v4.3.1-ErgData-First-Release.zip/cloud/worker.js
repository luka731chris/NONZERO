/**
 * NONZERO Cloud Worker v3 — ErgData-first orchestration
 * Bindings:
 *   NONZERO_STATE : Workers KV namespace
 * Secret:
 *   C2_API_TOKEN  : Concept2 Logbook bearer token (results:read)
 * Optional Cron:  * * * * *  (once/minute) for automatic result reconciliation
 */
const cors={
 'Access-Control-Allow-Origin':'*',
 'Access-Control-Allow-Methods':'GET,PUT,POST,OPTIONS',
 'Access-Control-Allow-Headers':'Content-Type,X-NONZERO-Key',
 'Access-Control-Max-Age':'86400','Cache-Control':'no-store'
};
const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,'Content-Type':'application/json'}});
async function hashKey(key){const bytes=new TextEncoder().encode(key);const digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('')}
function validKey(req){const key=(req.headers.get('X-NONZERO-Key')||'').trim();return key.length>=16?key:null}
async function readPayload(env,storageKey){const raw=await env.NONZERO_STATE.get(storageKey);if(!raw)return null;try{return JSON.parse(raw)}catch{return null}}
async function writePayload(env,storageKey,state){const updatedAt=Date.now();state._meta={...(state._meta||{}),schema:6,updatedAt};const payload={state,updatedAt};await env.NONZERO_STATE.put(storageKey,JSON.stringify(payload));return payload}
function localDate(){return new Date().toISOString().slice(0,10)}
async function latestConcept2(env,from){
 if(!env.C2_API_TOKEN)throw new Error('concept2_token_not_configured');
 const u=new URL('https://log.concept2.com/api/users/me/results');u.searchParams.set('number','10');if(from)u.searchParams.set('from',from);
 const r=await fetch(u.toString(),{headers:{'Authorization':'Bearer '+env.C2_API_TOKEN,'Accept':'application/vnd.c2logbook.v1+json','Content-Type':'application/json'}});
 if(!r.ok)throw new Error('concept2_'+r.status);const b=await r.json();const rows=Array.isArray(b.data)?b.data:[];rows.sort((a,b)=>Number(b.id||0)-Number(a.id||0));return rows[0]||null;
}
function mappedMetrics(r){
 if(!r)return null;const t=Number(r.time||0),d=Number(r.distance||0);const secs=t/10;const pace=(d>0&&secs>0)?(secs/(d/500)):null;
 return {durationMinutes:t?+(t/600).toFixed(2):null,distance:r.distance??null,calories:r.calories_total??null,paceSeconds:pace,avgWatts:r.watts??null,rate:r.stroke_rate??r.cadence??null,avgHr:r.heart_rate?.average??r.heart_rate_average??null,maxHr:r.heart_rate?.max??r.heart_rate_max??null,dragFactor:r.drag_factor??null};
}
async function startErg(env,storageKey,hash,body={}){
 let payload=await readPayload(env,storageKey);if(!payload?.state)throw new Error('state_not_initialized');let s=payload.state,a=s.activeWorkout||{};
 if(a.status==='active'&&a.source==='ergdata-automation'){return {state:s,idempotent:true}}
 let baseline=null;try{baseline=await latestConcept2(env,localDate())}catch{}
 const now=Date.now();s.activeWorkout={...a,date:localDate(),name:'ErgData Session',type:'erg',mode:a.mode||'full',checks:a.checks||[],pain:a.pain??null,energy:a.energy??null,status:'active',source:'ergdata-automation',sessionId:a.sessionId||('erg-'+now.toString(36)),timer:{elapsedMs:0,running:true,startedAt:now},ergAutomation:{startedAt:now,baselineResultId:baseline?.id??null,awaitingResult:true,lastCheckAt:0},updatedAt:now};
 await writePayload(env,storageKey,s);await env.NONZERO_STATE.put('erg-active:'+hash,JSON.stringify({storageKey,startedAt:now}),{expirationTtl:21600});return {state:s,idempotent:false};
}
async function pauseErg(env,storageKey){let p=await readPayload(env,storageKey);if(!p?.state)throw new Error('state_not_initialized');let s=p.state,a=s.activeWorkout;if(!a)return {state:s};const now=Date.now(),t=a.timer||{};if(t.running&&t.startedAt)t.elapsedMs=Number(t.elapsedMs||0)+(now-Number(t.startedAt));t.running=false;t.startedAt=null;a.timer=t;a.status='paused';a.updatedAt=now;await writePayload(env,storageKey,s);return {state:s}}
async function resetErg(env,storageKey,hash){let p=await readPayload(env,storageKey);if(!p?.state)throw new Error('state_not_initialized');let s=p.state,a=s.activeWorkout||{};s.activeWorkout={...a,status:'ready',timer:{elapsedMs:0,running:false,startedAt:null},ergAutomation:null,updatedAt:Date.now()};await writePayload(env,storageKey,s);await env.NONZERO_STATE.delete('erg-active:'+hash);return {state:s}}
async function reconcileOne(env,hash,marker){
 const storageKey=marker.storageKey;let p=await readPayload(env,storageKey);if(!p?.state){await env.NONZERO_STATE.delete('erg-active:'+hash);return}
 let s=p.state,a=s.activeWorkout;if(!a||a.source!=='ergdata-automation'||!['active','paused'].includes(a.status)){await env.NONZERO_STATE.delete('erg-active:'+hash);return}
 const now=Date.now(),started=Number(a.ergAutomation?.startedAt||marker.startedAt||now);if(now-started>4*60*60*1000){a.status='stale';a.timer={elapsedMs:Math.max(0,now-started),running:false,startedAt:null};a.updatedAt=now;await writePayload(env,storageKey,s);await env.NONZERO_STATE.delete('erg-active:'+hash);return}
 let r;try{r=await latestConcept2(env,new Date(started-3600000).toISOString().slice(0,10))}catch{return}
 a.ergAutomation={...(a.ergAutomation||{}),lastCheckAt:now};const baseline=a.ergAutomation.baselineResultId;
 if(!r||String(r.id)===String(baseline))return;
 // A new Concept2 result after the automation started is the authoritative completion signal.
 a.concept2={id:r.id,date:r.date,type:r.type,source:r.source||'Concept2 Logbook',importedAt:now};a.ergMetrics=mappedMetrics(r);a.name=(r.type==='bike'?'BikeErg':r.type==='rower'?'RowErg':r.type==='skierg'?'SkiErg':'Erg')+' · ErgData';a.type=r.type||'erg';a.status='complete';a.timer={elapsedMs:Number(r.time||0)*100,running:false,startedAt:null};a.ergAutomation={...(a.ergAutomation||{}),awaitingResult:false,reconciledAt:now};a.updatedAt=now;await writePayload(env,storageKey,s);await env.NONZERO_STATE.delete('erg-active:'+hash);
}
export default {
 async fetch(request,env){
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});const url=new URL(request.url);
  if(url.pathname==='/health')return json({ok:true,service:'nonzero-sync',version:3,ergDataFirst:true,concept2:!!env.C2_API_TOKEN});
  const key=validKey(request);if(!key)return json({error:'missing_or_invalid_key'},401);const hash=await hashKey(key),storageKey='state:'+hash;
  if(url.pathname==='/state'){
   if(request.method==='GET'){const raw=await env.NONZERO_STATE.get(storageKey);return raw?new Response(raw,{status:200,headers:{...cors,'Content-Type':'application/json'}}):json({state:null,updatedAt:0})}
   if(request.method==='PUT'){let b;try{b=await request.json()}catch{return json({error:'invalid_json'},400)}if(!b||typeof b.state!=='object'||!Array.isArray(b.state.sessions))return json({error:'invalid_state'},400);const payload=await writePayload(env,storageKey,b.state);return json({ok:true,updatedAt:payload.updatedAt})}
   return json({error:'method_not_allowed'},405);
  }
  if(url.pathname==='/concept2/latest'&&request.method==='GET'){try{const r=await latestConcept2(env,url.searchParams.get('from')||localDate());return json({result:r})}catch(e){return json({error:e.message},503)}}
  if(url.pathname==='/intent/erg/start'&&request.method==='POST'){let b={};try{b=await request.json()}catch{}try{const x=await startErg(env,storageKey,hash,b);return json({ok:true,activeWorkout:x.state.activeWorkout,idempotent:x.idempotent})}catch(e){return json({error:e.message},409)}}
  if(url.pathname==='/intent/erg/pause'&&request.method==='POST'){try{const x=await pauseErg(env,storageKey);return json({ok:true,activeWorkout:x.state.activeWorkout})}catch(e){return json({error:e.message},409)}}
  if(url.pathname==='/intent/erg/reset'&&request.method==='POST'){try{const x=await resetErg(env,storageKey,hash);return json({ok:true,activeWorkout:x.state.activeWorkout})}catch(e){return json({error:e.message},409)}}
  return json({error:'not_found'},404);
 },
 async scheduled(event,env,ctx){
  ctx.waitUntil((async()=>{let cursor;do{const page=await env.NONZERO_STATE.list({prefix:'erg-active:',cursor});for(const k of page.keys){const raw=await env.NONZERO_STATE.get(k.name);if(!raw)continue;try{await reconcileOne(env,k.name.slice('erg-active:'.length),JSON.parse(raw))}catch{}}cursor=page.list_complete?undefined:page.cursor}while(cursor)})());
 }
};
