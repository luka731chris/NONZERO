# NONZERO Roku Wall v4.0.5

## Pairing input fix
- Replaced legacy `KeyboardDialog` with Roku `StandardPinPadDialog` for numeric-only pairing.
- PIN entry is capped at six digits.
- Pairing auto-submits after digit six.
- Submission is deferred 150 ms after the sixth digit so Roku can finish processing the remote key event before the modal closes.
- Removed the `Pair Wall` confirmation button; only `Cancel` remains.
- Preserves the v4.0.2 font/rendering correction and existing Wall UI/state logic.

## Expected flow
1. Generate a fresh six-digit code in the NONZERO iPhone app.
2. On the Wall, press `*` (or OK while unpaired).
3. Enter six digits using the native numeric PIN pad.
4. After digit six, the dialog closes and the Wall shows `PAIRING…` / `CONNECTING WALL` automatically.
