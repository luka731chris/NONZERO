# NONZERO Roku v4.2.9 — Adaptive Quote Taste Engine

- Replaces the fixed weighted playlist with a local adaptive recommender.
- 55% anchor / 30% adjacent / 15% discovery mix for real-world voices.
- 90% real attributed quotes / 10% NONZERO originals.
- Learns author, domain, and theme affinities locally from Roku remote feedback.
- Ambient controls: OK = more like this; LEFT = less like this; RIGHT = next.
- Avoids immediate quote repeats, repeated authors, and domain streaks.
- Adds exposure decay so familiar favorites do not crowd out discovery.
- Quote rotation cadence: 16 seconds.
- Preserves read-only cloud state, pairing, workout state, and Wall scheduling.
