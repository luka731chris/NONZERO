# NONZERO Roku Wall v4.1.0

## Ambient Wall / screensaver
- New quote-first ambient experience designed to be the first/last garage view.
- Large rotating motivational quote every 24 seconds with soft fade animation.
- Ambient KPI cards: current streak, workouts this week, weekly minutes, 30-day completion.
- Today card shows the scheduled workout or completed-day status.
- Roku screensaver launches the same Ambient Wall experience.
- Date/time remains Roku-local and refreshes every second.

## Performance Wall
- Automatically switches from Ambient Wall when activeWorkout appears in shared cloud state (2-second polling).
- Live workout time, current movement, progress rail, HR, calories, output/cadence, and distance.
- 75-second post-workout results hold, then automatically returns to Ambient Wall.

## Pairing / connection hardening
- Preserves existing wall token and paired registry state across upgrades.
- Successful /pair/claim persists wallToken + paired=true before any state read.
- Successful pairing force-enters Wall immediately; /state continues in background.
- Five-second pairing transition watchdog re-enters Wall and restarts polling if the UI is still caught in CONNECTING after local pairing succeeds.
- Pairing keypad remote events remain local-only; network work starts only after all six digits are entered.
- No Worker URL or private sync key changes required.
