# NONZERO Roku Wall v4.1.5 — Stability Baseline

Built directly from the last Roku build proven to render Ambient Wall (v4.1.1).

## Priority 1 — restore the live scene heartbeat
- Fixed the v4.1.1 initialization fault in `onClock()`: `roDateTime.GetWeekday()`/weekday data was being sent into `UCase()` as a number. The clock painted once, then init aborted before the recurring timers were started.
- Uses `GetDayOfWeek()` with a fixed weekday-name table instead.
- Adds seconds to the clock temporarily so a live heartbeat is visually undeniable during testing.

## Expected downstream recovery
Because v4.1.1 starts the clock timer, quote timer, startup timer, and cloud polling only after the first `onClock()` call, fixing this single fault should also allow:
- the clock to refresh each second;
- quotes to rotate on the existing 24-second timer;
- deferred startup to run;
- 2-second cloud-state polling to begin;
- KPI cards to populate if the existing pairing token and Worker response are valid.

## Intentionally NOT changed
- No new background ClockTask.
- No extra timer architecture.
- No Worker URL changes.
- No pairing reset or credential migration.
- No additional KPI visual redesign in this release.

This release is intentionally narrow: prove the stable runtime first, then layer UI polish back on top.
