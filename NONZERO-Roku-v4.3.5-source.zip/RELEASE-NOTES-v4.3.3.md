# NONZERO Roku v4.3.3 / Cloud Worker v4 — Quote Discovery

## What changed
- Quote selection is now cloud-backed, with the packaged 132-quote library retained as offline fallback.
- Worker exposes a personalized `/quotes/feed` and `/quotes/feedback` API.
- Feed refreshes at launch and every 30 minutes while the Wall is running.
- Recommendation blend: 70% high-affinity, 20% adjacent discovery, 10% wildcard discovery.
- Unfamiliar authors receive a discovery bonus when their themes match learned preferences.
- Repetition penalties remain active locally on Roku in addition to cloud profile logic.
- Roku controls are now intuitive: UP = MORE, DOWN = LESS, RIGHT = NEXT.
- Feedback learns author, domain, and theme/tag affinity.
- Optional `QUOTE_SOURCE_URL` lets the Worker ingest a remote JSON quote database without changing the Roku package.
- External feeds are normalized, de-duplicated, tagged, and cached in KV every six hours.

## Compatibility
- v4.1.9-derived pairing/runtime architecture is unchanged.
- ErgData-first workout/session behavior is unchanged.
- Ambient, Performance, Night and Deep schedules are unchanged.
- v4.3.2 flag and LukaLab visual refinements are preserved.

## Validation
- Roku XML parsed successfully.
- Referenced package assets validated.
- Cloud Worker JavaScript passed `node --check`.
- ZIP root/manifest layout validated.
- Actual Roku BrightScript device compilation is still required after sideload.
