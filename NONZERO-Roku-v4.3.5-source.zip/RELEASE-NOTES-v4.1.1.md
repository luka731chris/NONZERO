# NONZERO Roku Wall v4.1.1

## Startup / splash hang hardening

- Scene initialization is now completely non-blocking.
- A safe Ambient Wall frame renders before any cloud request or full workout-state calculation.
- Registry loading remains local-only during init; cloud polling starts only from a post-show startup timer.
- Existing paired TVs immediately show Ambient Wall with live date/time and motivational quote while state sync continues in the background.
- The TV can no longer require the first `/state` response before presenting Wall UI.
- Pairing success still persists `wallToken` + `paired=true`, immediately enters Wall, restarts polling, and fetches state in the background.
- Pairing watchdog and request timeout protections remain in place.
- Reduced mandatory Roku splash minimum from 650 ms to 250 ms.

This build intentionally preserves the existing Worker URL, pairing credentials, Ambient/Performance architecture, quote rotation, KPI cards, and automatic live-workout transition.
