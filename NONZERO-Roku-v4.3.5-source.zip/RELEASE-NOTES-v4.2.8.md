# NONZERO Roku Wall v4.2.8

## Flag position + verified quote rotation
- Moved the American flag farther right and enlarged it slightly while preserving a clean gap before the clock/date cluster.
- Applied the same right-edge flag refinement to Night Mode.
- Replaced the Ambient celebrity-adaptation pool with a curated verified real-world quote pool.
- Primary voices now prioritize David Goggins, Jocko Willink, Adm. William McRaven, Colin Powell, U.S. presidents/military leaders, Mike Tomlin, Bill Cowher, Tom Brady, and elite performance psychologists.
- NONZERO originals remain as intentional filler lines rather than masquerading as public-figure quotes.
- Quote selection is weighted 80% verified real-world / 20% NONZERO original.
- Reduced quote rotation cadence from 34 seconds to 18 seconds and shortened crossfades for a more dynamic Ambient Wall.
- Preserved pairing, cloud sync, scheduling, KPI sizing, Night Mode clock, home-tile branding, and LukaLab artwork.
