# NONZERO Roku Wall v4.2.4

Built from v4.2.3 visuals on the stable v4.1.9 pairing/cloud runtime architecture.

- Adds scheduled Ambient, Night, and Deep Hibernate phases sourced from shared NONZERO state.
- Active workouts instantly override all scheduled idle modes and enter Performance Wall.
- Night Mode prioritizes a huge high-contrast digital clock and date with reduced motion.
- Deep Hibernate uses a nearly black screen, huge dim clock/date, and minimal branding for overnight panel protection.
- Transitions are local to the Roku clock and therefore instantaneous at the scheduled minute without requiring the phone to be open.
- Keeps the crisp American flag in the top header between cloud status and the standard clock/date.
- Preserves v4.1.9 pairing, wall-token persistence, startup-first rendering, cloud polling, and pairing watchdog behavior.

Shared state accepts:
```json
"wallSchedule": {"enabled": true, "ambient": "06:00", "night": "20:30", "deep": "01:00"}
```
