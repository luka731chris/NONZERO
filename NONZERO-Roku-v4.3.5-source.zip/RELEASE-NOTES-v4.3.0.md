# NONZERO Roku v4.3.0 — Durable Session Sync

- Started and paused phone workouts override Ambient/Night/Deep schedule until explicitly reset or completed.
- Adds a 30-second cloud-poll grace latch so one dropped/partial state response cannot kick a live workout back to Ambient.
- Explicit `ready` / `complete` state clears the latch immediately.
- Preserves v4.2.9 pairing, quote engine, Night Mode, branding, and layout.
- Performance header distinguishes paused sessions and ErgData-recording sessions without falsely claiming live PM5 telemetry when no bridge is connected.
