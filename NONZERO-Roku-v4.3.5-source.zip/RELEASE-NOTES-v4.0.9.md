# NONZERO Roku Wall v4.0.9

## Pair-success handoff hardening

- Treats a successful `/pair/claim` response as the definitive pairing transition.
- Persists `wallToken` plus `paired=true` before any state fetch.
- Immediately exits CONNECTING and renders the live Wall scene; if cloud state has not arrived yet, it shows a safe idle Wall for those few seconds.
- Restarts normal 2-second state polling immediately after pairing.
- Adds a 5-second pairing watchdog that re-forces Wall Mode if valid paired credentials exist but the UI has not transitioned.
- Existing saved wall credentials are promoted to `paired=true` automatically, so this update does not force a re-pair.
- Does not modify Worker URL/settings and does not unpair existing credentials.
