# NONZERO Roku Wall v4.2.7

## Header + KPI + Home tile refinement
- Tightened NONZERO + mode labeling into a contiguous brand cluster.
- Moved Cloud Live/connection status directly below NONZERO at far left.
- Pulled the American flag tightly against the date/time cluster at top right.
- Increased Ambient KPI values by two visual steps and increased supporting KPI typography proportionally.
- Increased live Performance KPI values and bottom summary KPI values by two visual steps.
- Replaced the Roku Home tile artwork with the NONZERO kettlebell/slash brand mark.
- Preserved pairing, cloud sync, scheduled display modes, Night Mode clock implementation, and LukaLab lockup.
