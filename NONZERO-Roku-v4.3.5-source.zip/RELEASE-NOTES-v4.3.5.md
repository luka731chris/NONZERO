# NONZERO Roku Wall v4.3.5 — Victory + Surgery Countdown

Built forward from v4.3.4. The verified Basecamp remains untouched.

## New behavior
- Workout complete: 75-second Performance victory lap, then Ambient becomes a celebration state for the rest of that day.
- Completed-day quotes are dynamically biased toward accomplishment, earned progress, consistency, identity, recovery, and momentum.
- Incomplete-day quotes retain the standard motivational architecture.
- New shared `quoteContext` field drives the local adaptive quote scorer without changing the Cloudflare quote API.
- Reads optional shared state `surgeryPlan.date` (`YYYY-MM-DD`).
- When a surgery date exists, Ambient's right rail becomes a live pre-op mission countdown with days remaining, phase, date, today's workout state, and phase-specific directive.
- Phases: BUILD BASE (>84d), BUILD CAPACITY (43–84d), CONSISTENCY BLOCK (15–42d), ARRIVE READY (4–14d), FINAL APPROACH (1–3d), SURGERY DAY, POST-OP.
- Existing v4.3.4 Deep Panel Protect / keep-awake behavior is preserved.
- Pairing/runtime protocol is unchanged.

## Companion phone
Phone v3.6 adds Settings → Hip surgery countdown. Leave blank while TBD. Once a date is entered it is stored in shared cloud state and drives the Roku countdown automatically.

## Worker
No Worker change required. Continue using the verified Worker v4.1.

## Validation performed
- SceneGraph XML parsed successfully.
- Phone inline JavaScript passed `node --check`.
- Manifest bumped to 4.3.5.
- ZIP integrity checked.
- No physical Roku compiler/device test was available in the build environment.
