# AutoPilot → NONZERO Wall Agenda Bridge

NONZERO v4.2.0 is display-ready for a privacy-minimized AutoPilot daily agenda. The Roku does not need access to full AutoPilot planner data.

## Recommended architecture
AutoPilot publishes only today's display summary into the existing NONZERO cloud state as `autopilotAgenda`. This keeps the Wall read-only and allows both apps to continue using their own internal models.

AutoPilot v47 is currently local-first, so the producer-side change should be added in AutoPilot as a small optional **Publish Wall Agenda** bridge. It can GET the existing NONZERO `/state`, merge the `autopilotAgenda` field, and PUT the state back using the existing private sync credential. The private key should remain browser-local and never be displayed on the Roku.

## Minimum payload
- `date`: local `YYYY-MM-DD`
- `status`: e.g. `On Track`, `Busy Day`, `Challenging`
- `items`: at most the day's logistics rows, each containing `time`, `title`, and optional `meta`

No calendar URLs, addresses, raw backup data, or two-week plan need to be sent to the Wall.
