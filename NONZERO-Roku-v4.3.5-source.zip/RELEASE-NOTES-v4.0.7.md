# NONZERO Roku Wall v4.0.7

## Fix
- Corrected the BrightScript compilation failure in `NonzeroWallScene.brs`.
- The v4.0.6 custom keypad used `box` as a variable name; `Box` is a reserved BrightScript word. It has been renamed to `keyBox`.
- Retains the custom in-scene 6-digit pairing keypad so Roku keyboard/PIN dialog focus is no longer involved.
- Pairing still auto-submits after the sixth digit.

## Install
Sideload `NONZERO-Roku-v4.0.7-sideload.zip` directly over the prior developer build.
