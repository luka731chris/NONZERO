# NONZERO Wall v4.2.8 — Quote Provenance

The Ambient Wall primary quote pool contains verified real-world quotations. NONZERO-written lines are explicitly attributed to NONZERO and are used as fillers.

- David Goggins — “Don't stop when you're tired. Stop when you're done.” — official David Goggins store product description: https://shop.davidgoggins.com/collections/apparel/products/stay-hard-black-blended-tee
- Jocko Willink — “Discipline equals freedom.” — Jocko.com: https://jocko.com/about/
- Jocko Willink — “Stop. Making. Excuses. Take action. Own your decisions. Execute.” — Jocko.com FAQ: https://jocko.com/faq/
- Adm. William McRaven — “If you want to change the world, start off by making your bed.” — University of Texas commencement transcript: https://news.utexas.edu/2014/05/16/mcraven-urges-graduates-to-find-courage-to-change-the-world/
- Colin Powell — “Perpetual optimism is a force multiplier.” — U.S. Department of State archive: https://2001-2009.state.gov/secretary/former/powell/remarks/33168.htm
- Colin Powell — “Remain calm. Be kind.” — U.S. Department of State: https://2021-2025.state.gov/dipnote-u-s-department-of-state-official-blog/colin-l-powells-thirteen-rules-of-leadership/
- Dwight Eisenhower — “Plans are worthless, but planning is everything.” — Eisenhower Presidential Library: https://www.eisenhowerlibrary.gov/eisenhowers/quotes
- Franklin D. Roosevelt — “The only thing we have to fear is fear itself.” — FDR Presidential Library: https://www.fdrlibrary.org/fdr-facts
- Ronald Reagan — “Trust, but verify.” — Ronald Reagan Presidential Library: https://www.reaganlibrary.gov/archives/speech/remarks-signing-intermediate-range-nuclear-forces-treaty
- Theodore Roosevelt — “The credit belongs to the man who is actually in the arena.” — Citizenship in a Republic / Man in the Arena, Theodore Roosevelt Center: https://www.theodorerooseveltcenter.org/encyclopedia/culture-and-society/man-in-the-arena/
- Mike Tomlin — “The standard is the standard.” — Pittsburgh Steelers: https://www.steelers.com/news/hearing-from-coach-mike-tomlin-2998597
- Mike Tomlin — “We stay humble in times of excellence.” — Pittsburgh Steelers: https://www.steelers.com/news/head-coach-mike-tomlin-and-santonio-holmes-press-conference-959456
- Bill Cowher — “Re-establish the mind-set.” — Pittsburgh Steelers historical coaching profile: https://www.steelers.com/news/tomlin-steelers-a-perfect-match-15513466
- Tom Brady — “You need to earn it every day.” — New England Patriots press conference transcript: https://www.patriots.com/news/transcript-tom-brady-9-4
- Jim Loehr — “Energy, not time, is the fundamental currency of high performance.” — The Power of Full Engagement (book quotation; corroborated in public book excerpts).
- Michael Gervais — “There are only three things we can train in this life: our craft, our body, and our mind.” — Michael Gervais public post: https://www.linkedin.com/posts/drmichaelgervais_i-want-to-share-something-foundational-activity-7405281673828962304-rp66
