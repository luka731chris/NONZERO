# NONZERO Roku Wall v4.1.8

Stability-first diagnostic release rebuilt from v4.1.5.

- Moves ambient clock updates to the BrightScript main event loop using a 1-second wait timeout.
- Moves quote rotation to the main event loop (20 seconds).
- Removes dependence on SceneGraph Timer callbacks for the two easiest-to-observe dynamic functions.
- Calls cloud startup once directly from scene init instead of waiting for startupTimer.
- Preserves pairing credentials, pairing UI, Ambient Wall, and Performance Wall code from the v4.1.5 baseline.
- Intentionally avoids additional animation/task changes until the main heartbeat is proven on-device.
