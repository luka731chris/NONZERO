# NONZERO Quote Source & Provenance Guide — v4.3.2

The library intentionally prioritizes primary/official sources and public-domain primary texts. Modern lines with weaker provenance are assigned a lower `source` score so the recommender favors stronger records.

## Primary / official source families
- Marcus Aurelius, *Meditations*, George Long public-domain translation — MIT Internet Classics Archive: https://classics.mit.edu/Antoninus/meditations.html
- Epictetus, *Enchiridion* and *Discourses*, public-domain translations — MIT Internet Classics Archive: https://classics.mit.edu/Epictetus/epicench.html
- Seneca, *Moral Letters to Lucilius* and *On the Shortness of Life* — Wikisource public-domain editions: https://en.wikisource.org/wiki/Moral_letters_to_Lucilius and https://en.wikisource.org/wiki/On_the_shortness_of_life
- Gene Kranz — NASA oral history/podcast: https://www.nasa.gov/podcasts/houston-we-have-a-podcast/call-sign-white-flight/
- Mike Tomlin — Pittsburgh Steelers transcripts: https://www.steelers.com/news/hearing-from-coach-mike-tomlin-2998597
- Tom Brady and Bill Belichick — New England Patriots press transcripts: https://www.patriots.com/news/transcript-tom-brady-9-4 and https://www.patriots.com/news/bill-belichick-transcript-they-ve-done-a-good-job-in-all-three-phases-of--213291
- Nick Saban — Alabama Athletics press transcripts: https://rolltide.com/news/2007/10/3/Nick_Saban_Weekly_Press_Conference_Transcript and https://rolltide.com/news/2007/8/5/Nick_Saban_Pre_Practice_Press_Conference_Transcript_August_5_2007
- John Wooden — official Coach Wooden Pyramid of Success: https://coachwooden.com/pyramid-of-success and UCLA: https://newsroom.ucla.edu/releases/john-wooden-dies-84109
- Pat Summitt — University of Tennessee Definite Dozen: https://utsports.com/sports/2017/6/20/coach-pat-summitt-1952-2016
- Kobe Bryant — Los Angeles Lakers/NBA interview archive: https://www.nba.com/lakers/news/kobe-surpasses-jordan-141212
- Jeff Bezos — Amazon shareholder letters: https://www.aboutamazon.com/news/company-news/amazons-original-1997-letter-to-shareholders and https://www.aboutamazon.com/news/company-news/2016-letter-to-shareholders
- Steve Jobs — Stanford 2005 commencement transcript: https://news.stanford.edu/stories/2005/06/steve-jobs-2005-graduates-stay-hungry-stay-foolish
- Satya Nadella — Microsoft growth-mindset materials: https://learn.microsoft.com/en-us/services-hub/release-notes/services-hub-news/growth-mindset
- Theodore Roosevelt — Theodore Roosevelt Center / public speeches: https://www.theodorerooseveltcenter.org/
- FDR — Franklin D. Roosevelt Presidential Library: https://www.fdrlibrary.org/
- Dwight Eisenhower — Eisenhower Presidential Library: https://www.eisenhowerlibrary.gov/eisenhowers/quotes
- Ronald Reagan — Reagan Presidential Library: https://www.reaganlibrary.gov/archives/speech/remarks-signing-intermediate-range-nuclear-forces-treaty
- Colin Powell — U.S. Department of State archives.
- William McRaven — University of Texas commencement transcript: https://news.utexas.edu/2014/05/16/mcraven-urges-graduates-to-find-courage-to-change-the-world/
- U.S. flag geometry — Executive Order 10834, National Archives: https://www.archives.gov/federal-register/codification/executive-order/10834.html

## Engine policy
- Source score 3: primary/official transcript or public-domain primary text.
- Source score 2: authoritative published/organizational source.
- Source score 1: widely documented attribution retained for breadth; engine gives it less weight.
- NONZERO originals are source score 0 and deliberately limited to occasional filler.
