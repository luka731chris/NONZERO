# NONZERO Roku Wall v4.2.1

Stable baseline: v4.1.9. Builds visually on v4.2.0 without changing pairing, Worker endpoint, wall token, or state polling architecture.

## Ambient refinements
- Randomized quote selection across the full library on startup and every 34 seconds; avoids immediate repeats.
- Expanded the library with additional sports, performance, psychology, and historical motivators.
- Replaced the simple quote pulse with a two-layer 1.35–1.65 second crossfade.
- Reworked KPI and lower panels into an iOS-inspired translucent glass treatment using alpha PNG surfaces, fine highlights, and softer accents.
- Replaced the header Ø glyph with the approved NONZERO kettlebell/slash emblem.
- Added the approved LukaLab thin-line Pittsburgh skyline motif as a subtle footer watermark.
- Preserves AutoPilot Today agenda adapter from v4.2.0.
