# NONZERO Roku v4.1.9

Targeted runtime-crash fix based on Roku BrightScript debugger output.

- Fixes renderState crash at former line 456 caused by `getProgram()` returning invalid.
- Replaces padded `stri()` program-map key with `(dow + 1).toStr()` and adds a safe Recovery fallback.
- Fixes dynamic step node IDs (`step1`..`step5`) to use `.toStr()` so `findNode()` cannot receive padded IDs.
- Fixes ISO date construction to use `.toStr()` so dates are `YYYY-MM-DD` without embedded spaces.
- Preserves pairing credentials, Worker endpoint, Ambient design, and v4.1.8 deterministic host heartbeat.
