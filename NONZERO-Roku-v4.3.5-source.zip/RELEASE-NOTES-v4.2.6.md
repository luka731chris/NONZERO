# NONZERO Roku v4.2.6

## Night Mode clock refinement
- Replaced sharp/beveled seven-segment artwork with softer rounded digital segments.
- Changed the primary Night Mode clock digits and colon to true night red.
- Changed the primary Night Mode AM/PM and date to matching red.
- Preserved the white header clock/date for visual hierarchy.
- No changes to pairing, cloud sync, scheduling, Ambient, Performance, or LukaLab branding.
