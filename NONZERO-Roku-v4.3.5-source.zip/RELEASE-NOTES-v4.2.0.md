# NONZERO Roku Wall v4.2.0

Stable baseline: v4.1.9.

## Changes
- Centralizes Ambient quote ownership in the proven `main.brs` heartbeat so 2-second cloud renders cannot reset the quote.
- Expands the rotating library to 54 motivational quotes with visible author attribution.
- Quote dwell time increased to 34 seconds for garage-distance readability.
- Reworks Ambient KPI cards into a cleaner premium four-card rail without changing KPI calculations.
- Adds an AutoPilot Today Agenda panel with three glanceable rows.
- Adds a safe agenda adapter for `state.autopilotAgenda`, `state.autoPilotAgenda`, or `state.agenda`.
- Preserves v4.1.9 pairing, cloud endpoint, polling, and stable main-thread heartbeat architecture.

## AutoPilot wall-state contract
```json
{
  "autopilotAgenda": {
    "date": "2026-08-29",
    "status": "On Track",
    "items": [
      {"time":"7:50 AM","title":"School bus","meta":"Home"},
      {"time":"3:30 PM","title":"Whitney · Gymnastics","meta":"Driver: Kira"},
      {"time":"6:00 PM","title":"Soccer practice","meta":"Driver: Chris"}
    ]
  }
}
```
Only the first three rows are shown; additional rows are summarized as `+N MORE`.
