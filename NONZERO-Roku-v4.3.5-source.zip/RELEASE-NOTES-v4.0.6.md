# NONZERO Roku Wall v4.0.6

## Pairing input rebuild

This release removes Roku keyboard and PIN-pad dialog nodes from the pairing flow. The pairing keypad is now a lightweight SceneGraph overlay controlled directly by the Wall scene's remote-key handler.

- Arrow keys move between digits.
- OK appends the selected digit.
- Back deletes the most recent digit; Back again with an empty code exits.
- Cancel exits pairing.
- Delete removes the most recent digit.
- Pairing submits automatically after six digits.
- The cloud pairing task and v4.0.2 font/rendering fixes remain unchanged.

The purpose of this implementation is to bypass the modal keyboard/pin-pad focus path that froze on the first OK press on the target Roku TV.
