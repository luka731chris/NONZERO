# NONZERO Roku v4.3.1 — ErgData-First Wall

- Recognizes Worker-created `ergdata-automation` sessions as first-class Performance sessions.
- Performance context shows `ERGDATA / PM5 · RECORDING · AUTO SYNC` without falsely claiming live PM5 telemetry.
- Explicit stale-session state releases the Wall back to its normal schedule.
- Preserves v4.3.0 dropout latch, v4.2.9 quote engine, pairing architecture, Night mode, and branding.
