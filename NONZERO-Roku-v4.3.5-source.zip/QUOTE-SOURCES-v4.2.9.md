# Quote Sources — v4.2.9

The engine prefers primary/official sources and short attributable lines. Modern-source anchors include:

- David Goggins official shop — Stay Hard apparel description.
- Jocko.com — About / FAQ.
- University of Texas — Admiral William McRaven commencement transcript.
- Steelers.com — Mike Tomlin interviews and organizational history.
- Patriots.com — Tom Brady and Bill Belichick press conference transcripts.
- NASA — Gene Kranz interviews / APPEL material.
- Stanford University — Steve Jobs 2005 commencement transcript.
- UCLA / CoachWooden.com — John Wooden philosophy and quotations.
- Alabama Athletics — Nick Saban press conference transcripts.
- University of Tennessee — Pat Summitt Definite Dozen.
- TED — Angela Duckworth grit materials.
- Team Never Quit — Marcus Luttrell / SEAL ethos materials.
- Microsoft — Satya Nadella growth-mindset materials.
- Berkshire Hathaway — Warren Buffett manager memo / annual report.
- Virgin — Richard Branson Q&A.
- AWS Executive Insights — Jeff Bezos shareholder-letter excerpts.

Historical presidential quotations are sourced from official presidential libraries, government archives, or the American Presidency Project. NONZERO originals are explicitly labeled NONZERO and are never presented as quotations from public figures.
