# NONZERO Roku Wall v4.2.5

## Night Mode layout + clock reliability
- Rebuilt Night Mode to match the approved black/gold clock-first mockup.
- Replaced the oversized text clock with image-based seven-segment digits for reliable Roku rendering.
- Added a deterministic main-thread heartbeat so Night/Deep clocks and scheduled phase transitions do not depend on SceneGraph Timer callbacks.
- Doubled the American flag visual area in Night Mode while keeping it contained inside the top header.
- Added dedicated Night header: NONZERO · NIGHT MODE · CLOUD LIVE · flag · time/date.
- Preserved the existing LukaLab AI Creative skyline lockup at bottom right.
- Ambient, Performance, six-digit pairing, and cloud-state architecture remain unchanged.

Baseline: v4.2.4, preserving the v4.1.9 pairing/runtime architecture.
