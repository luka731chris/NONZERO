# NONZERO Roku v4.0.8

Fixes the custom six-digit pairing overlay failing to open on some Roku TVs.

- Removes runtime-generated keypad node lookups.
- Caches all 12 keypad rectangles and labels explicitly during scene initialization.
- Adds defensive node checks and reasserts Scene focus when the pairing overlay opens.
- Keeps the modal-free custom numeric keypad and automatic submit after six digits.
