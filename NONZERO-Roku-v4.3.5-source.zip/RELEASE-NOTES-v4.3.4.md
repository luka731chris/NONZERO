# NONZERO Wall v4.3.4 — Appliance Overnight / Panel Protect

Built from the verified v4.3.3 Roku baseline. Pairing, cloud state, quote engine, Performance mode, Night mode, flag, and LukaLab branding are intentionally preserved.

## Changes
- Replaces the bright Deep Hibernate clock with **Deep Panel Protect**: nearly all-black screen with a tiny ultra-dim status cluster.
- The status cluster shifts among eight screen positions once per minute to reduce static-pixel exposure.
- Deep mode stops cloud quote-feed refresh and quote rotation while retaining the one-second scheduling heartbeat.
- Adds a tiny, muted, looping packaged video whose only purpose is to keep Roku in active-playback state while NONZERO is foregrounded, reducing the chance that the Roku OS screensaver takes over.
- The app remains alive overnight so the existing schedule can transition automatically from Deep Panel Protect to Ambient at the configured morning time (default 06:00).
- Adds playback watchdog logic to restart the keep-awake video if Roku reports it stopped, finished, or errored.

## Important platform limitation
NONZERO still cannot programmatically override a Roku TV's separate system-level auto-power-off setting. For 24/7 Wall operation, disable Roku/TCL auto power savings / four-hour power-off in TV settings.

## Baseline preserved
- Phone v3.5 / Worker v4.1 compatibility unchanged.
- Six-digit pairing unchanged.
- X-NONZERO-Wall cloud authentication unchanged.
- Performance-to-scheduled-mode reconciliation unchanged.
- No Cloudflare or GitHub phone changes are required for this Roku-only update.

## Validation performed
- XML well-formedness check.
- Manifest/version inspection.
- ZIP integrity check.
- Static source checks for keep-awake, Deep Panel Protect, and scheduled-transition hooks.

A physical Roku compiler/device test was not available during packaging.
