# NONZERO Roku v4.3.2 — Quote Intelligence + Flag/Branding Upgrade

## Quote engine
- Expanded active library to **132 quotes** across **49 originators** and **15 domains**.
- Added a major Stoic/classical channel: Marcus Aurelius, Epictetus, Seneca, Socrates, Plato, Aristotle, and Confucius.
- Broadened sports, military, spaceflight, behavioral psychology, performance psychology, business, public service, exploration, innovation, wisdom and positive-support voices.
- ~7% NONZERO originals; the rest are attributed external voices.
- Persistent 36-quote recency window and 10-author recency window survive app restarts.
- Fresh `NONZERO_QUOTES_V3` taste registry clears the old repetitive exposure history while preserving all workout/cloud pairing state.
- Selection no longer always chooses the single highest score; it randomly chooses within a competitive top band.
- Discovery rotations deliberately favor lightly exposed authors/domains.
- Up/down votes now learn quote + author + domain + theme affinity.
- Remote instructions are always visible: **LEFT = LESS · OK = MORE · RIGHT = NEXT**. Feedback confirms each vote on screen.
- Quote cadence is 17 seconds, with immediate rotation after vote/skip.

## American flag
- Rebuilt from geometry using Executive Order 10834 proportions: 13 equal stripes, 19:10 overall ratio, 7-stripe-high canton, staggered 6/5 star rows, true five-point stars.
- Flag is positioned 6 px from the shared clock and 6 px from the Night clock cluster.

## LukaLab
- Larger 360 px skyline lockup.
- LukaLab AI Creative increases from 20 px to 27 px.
- Stronger Pittsburgh studio descriptor and animated gold accent bar.

## Preserved
- v4.1.9 pairing/runtime architecture.
- v4.3.1 ErgData-first workout synchronization and Performance-mode behavior.
- Existing Night mode, cloud state, keypad pairing, and workout UI.
