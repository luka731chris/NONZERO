sub init()
    m.top.backgroundColor = "0x05080cff"
    m.top.setFocus(true)
    m.clockTimer = m.top.findNode("clockTimer")
    m.pollTimer = m.top.findNode("pollTimer")
    m.quoteTimer = m.top.findNode("quoteTimer")
    m.pairSubmitTimer = m.top.findNode("pairSubmitTimer")
    m.pairWatchdogTimer = m.top.findNode("pairWatchdogTimer")
    m.completionHoldTimer = m.top.findNode("completionHoldTimer")
    m.startupTimer = m.top.findNode("startupTimer")
    m.clockTimer.observeField("fire", "onClock")
    m.performanceTimer = m.top.findNode("performanceTimer")
    m.performanceTimer.observeField("fire", "updateLiveTimer")
    m.performanceTimer.control = "start"
    m.pollTimer.observeField("fire", "refreshState")
    m.pairSubmitTimer.observeField("fire", "onPairSubmitTimer")
    m.pairWatchdogTimer.observeField("fire", "onPairWatchdog")
    m.completionHoldTimer.observeField("fire", "onCompletionHold")
    m.startupTimer.observeField("fire", "onStartup")
    m.top.observeField("heartbeat", "onHeartbeat")
    m.quoteIndex = 0
    m.pairOverlayOpen = false
    m.pairCode = ""
    m.pairSelection = 0
    m.pairSubmitting = false
    m.pendingPairCode = ""
    m.paired = false
    m.wallMode = "ambient"
    m.wallSchedule = { enabled: true, ambient: "06:00", night: "20:30", deep: "01:00" }
    m.lastLiveSeen = 0
    m.activeGraceSeconds = 30
    m.wasLive = false
    m.holdActive = false
    m.deepLastMinute = -1
    m.top.quoteContext = "standard"
    m.motivationIndex = 0
    m.motivationLastRotate = 0
    m.motivationLastProgressCount = -1
    m.motivationFlashUntil = 0
    m.motivationFlashText = ""
    m.performanceClockSession = ""
    m.performanceClockStamp = -1
    m.performanceClockRunning = false
    m.performanceClockBaseMs = 0.0
    m.performanceClockSpan = CreateObject("roTimespan")
    m.performanceClockSpan.Mark()
    m.keepAwakeVideo = m.top.findNode("keepAwakeVideo")
    if m.keepAwakeVideo <> invalid then m.keepAwakeVideo.observeField("state", "onKeepAwakeState")
    ' Cache keypad nodes explicitly. Avoid constructing node IDs at runtime, which
    ' can fail silently on some Roku firmware/SceneGraph combinations.
    m.pairKeyBoxes = [
        m.top.findNode("pairKeyBox0"), m.top.findNode("pairKeyBox1"), m.top.findNode("pairKeyBox2"),
        m.top.findNode("pairKeyBox3"), m.top.findNode("pairKeyBox4"), m.top.findNode("pairKeyBox5"),
        m.top.findNode("pairKeyBox6"), m.top.findNode("pairKeyBox7"), m.top.findNode("pairKeyBox8"),
        m.top.findNode("pairKeyBox9"), m.top.findNode("pairKeyBox10"), m.top.findNode("pairKeyBox11")
    ]
    m.pairKeyLabels = [
        m.top.findNode("pairKeyLabel0"), m.top.findNode("pairKeyLabel1"), m.top.findNode("pairKeyLabel2"),
        m.top.findNode("pairKeyLabel3"), m.top.findNode("pairKeyLabel4"), m.top.findNode("pairKeyLabel5"),
        m.top.findNode("pairKeyLabel6"), m.top.findNode("pairKeyLabel7"), m.top.findNode("pairKeyLabel8"),
        m.top.findNode("pairKeyLabel9"), m.top.findNode("pairKeyLabel10"), m.top.findNode("pairKeyLabel11")
    ]
    m.quotes = [
        "ZERO IS THE ONLY MISS.",
        "TEN MINUTES BEATS ZERO.",
        "SHOW UP. PUT A NUMBER ON THE BOARD.",
        "PROTECT THE NEXT GOOD CHOICE BEFORE MOTIVATION ARRIVES."
    ]
    m.lastState = invalid
    m.currentActive = invalid
    ' IMPORTANT: init must never perform network work or full state rendering.
    ' CreateScene() does not return until init completes, so a runtime fault here
    ' leaves Roku showing only the splash screen. Draw a safe Ambient Wall first,
    ' then defer registry-dependent rendering and cloud polling until after Show().
    loadSettings()
    bootstrapAmbient()
    lukaPulse = m.top.findNode("lukalabPulse")
    if lukaPulse <> invalid then lukaPulse.control = "start"
    startKeepAwakeVideo()
    ' v4.1.8: ambient clock/quote are driven directly by main.brs.
    ' Keep cloud startup independent from any SceneGraph Timer firing.
    onStartup()
end sub

sub loadSettings()
    appInfo = CreateObject("roAppInfo")
    m.endpoint = appInfo.GetValue("nonzero_worker_url")
    if m.endpoint = invalid or m.endpoint = "" then m.endpoint = "https://nonzero-sync.luka731chris.workers.dev"
    sec = CreateObject("roRegistrySection", "NONZERO")
    m.wallToken = sec.Read("wallToken")
    if m.wallToken = invalid then m.wallToken = ""
    pairedValue = sec.Read("paired")
    if pairedValue = invalid then pairedValue = ""
    m.paired = (m.wallToken <> "" and pairedValue = "true")

    ' A wallToken from an older build is already a valid pairing credential.
    ' Promote it to the explicit paired flag rather than forcing re-pairing.
    if m.wallToken <> "" and m.paired = false then
        m.paired = true
        sec.Write("paired", "true")
        sec.Flush()
    end if

end sub

sub bootstrapAmbient()
    ' This function intentionally touches only static SceneGraph nodes. It is the
    ' no-fail first frame and does not depend on cloud state, workout data, dates,
    ' program calculation, or registry contents.
    setWallMode("ambient")
    m.top.findNode("ambientStreak").text = "—"
    m.top.findNode("ambientWeek").text = "—"
    m.top.findNode("ambientMinutes").text = "—"
    m.top.findNode("ambient30").text = "—"
    m.top.findNode("ambientTodayLabel").text = "TODAY · READY"
    m.top.findNode("ambientToday").text = "NONZERO WALL"
    m.top.findNode("ambientTodayDetail").text = "Loading your latest state in the background."
    if m.wallToken <> "" then
        setCloudStatus("● PAIRED · SYNCING", "0x55d67aff")
    else
        setCloudStatus("● READY TO PAIR", "0xd58b38ff")
    end if
end sub

sub onStartup()
    ' Runs only after SceneGraph has had a chance to present the first frame.
    ' Cloud/network state can never block the Wall from becoming visible.
    if m.wallToken = "" then
        showPairingState()
        return
    end if

    m.paired = true
    setWallMode("ambient")
    setCloudStatus("● PAIRED · SYNCING", "0x55d67aff")

    ' Full local rendering is also deferred. If any old/cached state exists it
    ' can be used now; otherwise the safe Ambient frame remains on screen.
    if m.lastState <> invalid then renderState(m.lastState)

    restartPolling()
    refreshState()
end sub

sub showPairingState()
    setWallMode("performance")
    m.top.findNode("modePill").text = "PAIRING"
    m.top.findNode("stateBadge").text = "PAIR"
    m.top.findNode("stateBadge").color = "0xd58b38ff"
    m.top.findNode("session").text = "PAIR NONZERO WALL"
    m.top.findNode("why").text = "On your phone: Settings → Roku Wall pairing → Generate 6-digit code. Press * here and enter only those six digits."
    m.top.findNode("currentMove").text = "6-DIGIT PAIRING"
    m.top.findNode("currentDetail").text = "No Worker URL or private sync key required on the TV."
    m.top.findNode("liveTimer").text = "••••••"
    m.top.findNode("timerLabel").text = "ONE-TIME CODE"
    setCloudStatus("● NOT PAIRED", "0xd58b38ff")
    m.top.findNode("pairHint").text = "PRESS * TO ENTER 6-DIGIT CODE"
    setPerformanceIdle()
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    if m.pairOverlayOpen = true then
        if key = "left" then
            movePairSelection(-1, 0)
            return true
        else if key = "right" then
            movePairSelection(1, 0)
            return true
        else if key = "up" then
            movePairSelection(0, -1)
            return true
        else if key = "down" then
            movePairSelection(0, 1)
            return true
        else if key = "OK" then
            selectPairKey()
            return true
        else if key = "back" then
            if len(m.pairCode) > 0 then
                m.pairCode = left(m.pairCode, len(m.pairCode) - 1)
                updatePairCodeDisplay()
            else
                closePairOverlay()
            end if
            return true
        else if key = "options" then
            closePairOverlay()
            return true
        end if
        return true
    end if

    if key = "options" then
        if m.top.isScreensaver then return false
        openPairOverlay()
        return true
    end if
    if key = "OK" and m.wallToken = "" and not m.top.isScreensaver then
        openPairOverlay()
        return true
    end if

    ' v4.3.3 quote discovery controls. Intuitive directional voting. Pairing retains priority above; these controls
    ' are active only on the normal Ambient Wall and do not write cloud state.
    if m.wallMode = "ambient" and not m.top.isScreensaver then
        if key = "up" then
            m.top.quoteAction = "more"
            return true
        else if key = "down" then
            m.top.quoteAction = "less"
            return true
        else if key = "right" then
            m.top.quoteAction = "next"
            return true
        end if
    end if
    return false
end function

sub openPairOverlay()
    m.pairOverlayOpen = true
    m.pairSubmitting = false
    m.pairCode = ""
    m.pairSelection = 0
    m.pendingPairCode = ""
    overlay = m.top.findNode("pairOverlay")
    if overlay = invalid then return
    overlay.visible = true
    m.top.setFocus(true)
    updatePairCodeDisplay()
    updatePairKeyFocus()
end sub

sub closePairOverlay()
    m.pairOverlayOpen = false
    m.pairSubmitting = false
    m.pairCode = ""
    m.pendingPairCode = ""
    m.top.findNode("pairOverlay").visible = false
end sub

sub movePairSelection(dx as Integer, dy as Integer)
    col = m.pairSelection mod 3
    row = int(m.pairSelection / 3)
    col = col + dx
    row = row + dy
    if col < 0 then col = 2
    if col > 2 then col = 0
    if row < 0 then row = 3
    if row > 3 then row = 0
    m.pairSelection = row * 3 + col
    updatePairKeyFocus()
end sub

sub selectPairKey()
    if m.pairSubmitting = true then return
    values = ["1","2","3","4","5","6","7","8","9","C","0","D"]
    v = values[m.pairSelection]
    if v = "C" then
        closePairOverlay()
        return
    else if v = "D" then
        if len(m.pairCode) > 0 then m.pairCode = left(m.pairCode, len(m.pairCode) - 1)
        updatePairCodeDisplay()
        return
    end if

    if len(m.pairCode) >= 6 then return
    m.pairCode = m.pairCode + v
    updatePairCodeDisplay()

    if len(m.pairCode) = 6 then
        m.pairSubmitting = true
        m.pendingPairCode = m.pairCode
        t = m.top.findNode("pairSubmitTimer")
        t.control = "stop"
        t.control = "start"
    end if
end sub

sub updatePairCodeDisplay()
    shown = ""
    for i = 1 to 6
        if i <= len(m.pairCode) then
            shown = shown + mid(m.pairCode, i, 1)
        else
            shown = shown + "•"
        end if
        if i < 6 then shown = shown + "  "
    end for
    m.top.findNode("pairCodeDisplay").text = shown
    m.top.findNode("pairCount").text = stri(len(m.pairCode)) + " / 6"
end sub

sub updatePairKeyFocus()
    for i = 0 to 11
        keyBox = m.pairKeyBoxes[i]
        keyLabel = m.pairKeyLabels[i]
        if keyBox <> invalid and keyLabel <> invalid then
            if i = m.pairSelection then
                keyBox.color = "0xd58b38ff"
                keyLabel.color = "0x05080cff"
            else
                keyBox.color = "0x17212bff"
                keyLabel.color = "0xf4f7f8ff"
            end if
        end if
    end for
end sub

sub onPairSubmitTimer()
    if m.pendingPairCode = invalid or len(m.pendingPairCode) <> 6 then
        m.pairSubmitting = false
        return
    end if
    code = m.pendingPairCode
    closePairOverlay()
    submitPairCode(code)
end sub

sub submitPairCode(code as String)
    ' Start a five-second safety timer. If pairing has succeeded locally but the
    ' UI somehow remains on CONNECTING, the watchdog forces Wall Mode.
    m.pairWatchdogTimer.control = "stop"
    m.pairWatchdogTimer.control = "start"

    task = CreateObject("roSGNode", "PairTask")
    task.endpoint = m.endpoint
    task.code = code
    task.observeField("result", "onPairResult")
    task.observeField("error", "onPairError")
    m.pairTask = task
    setCloudStatus("● PAIRING…", "0xd58b38ff")
    m.top.findNode("session").text = "CONNECTING WALL"
    m.top.findNode("why").text = "Code accepted. Connecting this Wall to NONZERO…"
    task.control = "run"
end sub

sub onPairResult()
    data = m.pairTask.result
    if data = invalid or data.wallToken = invalid or data.wallToken = "" then return

    ' Pairing is complete the instant /pair/claim returns a wall token. Persist
    ' the credential and explicit paired state BEFORE doing any state fetch.
    sec = CreateObject("roRegistrySection", "NONZERO")
    sec.Write("wallToken", data.wallToken)
    sec.Write("paired", "true")
    sec.Write("pairingDurable", "true")
    sec.Delete("syncKey")
    sec.Delete("endpoint")
    sec.Flush()

    m.wallToken = data.wallToken
    m.paired = true
    m.top.findNode("pairHint").text = "* PAIR / SETTINGS"

    ' Never hold the user on CONNECTING while waiting for /state. Enter Wall
    ' Mode immediately using a cached snapshot (or a safe idle state), then
    ' refresh from the cloud in the background.
    forceEnterWall()
    restartPolling()
    refreshState()
end sub

sub onPairWatchdog()
    ' Safety net: if the successful pair callback saved credentials but some
    ' UI path still left the scene on CONNECTING, force Wall Mode at ~5 sec.
    if m.paired = true and m.wallToken <> "" then
        forceEnterWall()
        restartPolling()
        refreshState()
    end if
end sub

sub forceEnterWall()
    m.pairOverlayOpen = false
    overlay = m.top.findNode("pairOverlay")
    if overlay <> invalid then overlay.visible = false

    if m.lastState <> invalid then
        renderState(m.lastState)
    else
        ' A successful pair is enough to leave CONNECTING. Cloud state may
        ' arrive moments later; show a valid Wall immediately in the meantime.
        renderState({ sessions: [], activeWorkout: invalid })
    end if

    setCloudStatus("● PAIRED · SYNCING", "0x55d67aff")
end sub

sub restartPolling()
    if m.pollTimer = invalid then return
    m.pollTimer.control = "stop"
    m.pollTimer.control = "start"
end sub

sub onPairError()
    err = m.pairTask.error
    if err = invalid or err = "" then err = "Pairing failed"

    ' A failed/slow claim must never leave CONNECTING WALL on screen forever.
    ' Preserve any existing credential; otherwise return to a clean pairing state.
    if m.wallToken <> "" then
        forceEnterWall()
        restartPolling()
    else
        showPairingState()
    end if
    setCloudStatus("● " + ucase(err), "0xfb7185ff")
    showPairMessage(err + ". Generate a new code on the phone and try again.")
end sub

sub showPairMessage(message as String)
    d = CreateObject("roSGNode", "Dialog")
    d.title = "NONZERO Wall"
    d.message = message
    d.buttons = ["OK"]
    m.top.dialog = d
end sub

sub refreshState()
    if m.endpoint = "" or m.wallToken = "" then return
    if m.task <> invalid and m.task.state = "run" then return
    task = CreateObject("roSGNode", "StateTask")
    task.endpoint = m.endpoint
    task.wallToken = m.wallToken
    task.observeField("result", "onState")
    task.observeField("error", "onStateError")
    m.task = task
    task.control = "run"
end sub

sub onState()
    data = m.task.result
    if data = invalid or data.state = invalid then return
    m.lastState = data.state

    ' Keep the explicit paired marker current after every successful cloud read.
    sec = CreateObject("roRegistrySection", "NONZERO")
    sec.Write("paired", "true")
    sec.Write("pairingDurable", "true")
    sec.Flush()
    m.paired = true

    renderState(data.state)
    setCloudStatus("● CLOUD LIVE", "0x55d67aff")
end sub

sub onStateError()
    err = m.task.error
    if err = invalid or err = "" then return

    ' v4.3.6 DURABLE PAIRING:
    ' A cloud/network/authentication error is NEVER interpreted as an unpair.
    ' Keep the registry credential forever and keep polling. The only way this
    ' app changes pairing is a successful explicit 6-digit pair initiated by
    ' the user with the * menu.
    m.paired = (m.wallToken <> "")
    sec = CreateObject("roRegistrySection", "NONZERO")
    if m.wallToken <> "" then
        sec.Write("wallToken", m.wallToken)
        sec.Write("paired", "true")
        sec.Flush()
    end if

    if instr(1, lcase(err), "credential rejected") > 0 then
        setCloudStatus("● CLOUD AUTH RETRY", "0xd58b38ff")
    else
        setCloudStatus("● CLOUD RETRYING", "0xd58b38ff")
    end if
end sub

sub setCloudStatus(text as String, color as String)
    n = m.top.findNode("cloudStatus")
    if n <> invalid then
        n.text = text
        n.color = color
    end if
    nn = m.top.findNode("nightCloudStatus")
    if nn <> invalid then
        ' Night header deliberately uses a short appliance-style status.
        if instr(1, text, "LIVE") > 0 or instr(1, text, "PAIRED") > 0 or instr(1, text, "SYNC") > 0 then
            nn.text = "● CLOUD LIVE"
            nn.color = "0x55d67aff"
        else
            nn.text = text
            nn.color = color
        end if
    end if
end sub

sub renderState(state as Object)
    if state.wallSchedule <> invalid then m.wallSchedule = normalizeWallSchedule(state.wallSchedule)
    sessions = state.sessions
    if sessions = invalid then sessions = []
    active = state.activeWorkout
    today = rokuDateString()
    completed = invalid
    for each s in sessions
        if s.date = today then completed = s
    end for

    explicitStop = false
    if active <> invalid and active.date <> today then active = invalid
    if active <> invalid then
        status = ""
        if active.status <> invalid then status = lcase(active.status.toStr())
        if status = "ready" or status = "complete" or status = "finished" or status = "reset" or status = "stale" then
            explicitStop = true
            active = invalid
            m.lastLiveSeen = 0
        else
            ' v4.3.0: started/paused sessions are first-class wall state. Legacy
            ' activeWorkout objects remain live-compatible for rollback safety.
            if status = "active" or status = "paused" or status = "running" or status = "" then
                nowDt = CreateObject("roDateTime")
                m.lastLiveSeen = nowDt.AsSeconds()
            end if
        end if
    else
        ' Briefly hold Performance through a dropped/partial cloud poll. An explicit
        ' ready/complete state clears immediately; silence only gets a 30s grace.
        if m.lastLiveSeen > 0 then
            nowDt = CreateObject("roDateTime")
            if nowDt.AsSeconds() - m.lastLiveSeen <= m.activeGraceSeconds and m.currentActive <> invalid then active = m.currentActive
        end if
    end if
    m.currentActive = active

    current = active
    if current = invalid then current = completed
    mode = "full"
    if current <> invalid and current.mode <> invalid then mode = lcase(current.mode)

    dtForProgram = CreateObject("roDateTime")
    dtForProgram.ToLocalTime()
    p = getProgram(dtForProgram.GetDayOfWeek())
    items = p.full
    if mode = "minimum" then items = p.minimum
    if mode = "flare" then items = getFlare()

    checks = []
    if current <> invalid and current.checks <> invalid then checks = current.checks

    done = 0
    currentIndex = -1
    for i = 0 to 4
        label = m.top.findNode("step" + (i + 1).toStr())
        if i < items.count() then
            checked = false
            if i < checks.count() then checked = checks[i]
            if checked then
                prefix = "✓  "
                done = done + 1
                label.color = "0x55d67aff"
            else
                if currentIndex = -1 then
                    currentIndex = i
                    prefix = "●  "
                    label.color = "0xd58b38ff"
                else
                    prefix = "○  "
                    label.color = "0xb6c0c8ff"
                end if
            end if
            label.text = prefix + items[i][0] + "  ·  " + items[i][1]
        else
            label.text = ""
        end if
    end for

    totalItems = items.count()
    pct = 0
    if totalItems > 0 then pct = int((done * 100) / totalItems)
    m.top.findNode("progress").width = int(1786 * pct / 100)
    glowX = 64 + int(1786 * pct / 100) - 40
    if glowX < 64 then glowX = 64
    if glowX > 1770 then glowX = 1770
    m.top.findNode("progressGlow").translation = [glowX, 828]

    if completed <> invalid and completed.completed = true then
        m.top.quoteContext = "accomplishment"
    else
        m.top.quoteContext = "standard"
    end if
    renderSurgeryCountdown(state, p, completed)

    if active <> invalid then
        m.holdActive = false
        m.completionHoldTimer.control = "stop"
        m.wasLive = true
        setWallMode("performance")
        renderLive(p, items, currentIndex, mode, active, pct)
    else if m.holdActive = true and completed <> invalid and completed.completed = true then
        setWallMode("performance")
        renderComplete(p, items, completed, mode, pct)
    else if m.wasLive = true and completed <> invalid and completed.completed = true then
        m.wasLive = false
        m.holdActive = true
        setWallMode("performance")
        renderComplete(p, items, completed, mode, pct)
        m.completionHoldTimer.control = "stop"
        m.completionHoldTimer.control = "start"
    else
        renderIdle(p, items, mode, pct)
        renderAmbient(p, completed)
        setWallMode(getScheduledWallMode())
    end if

    weekCount = 0
    weekMinutes = 0
    completeCount = 0
    totalStarts = sessions.count()
    weekStart = weekStartDate()
    streakDates = {}
    for each s in sessions
        if s.completed = true then
            streakDates[s.date] = true
            completeCount = completeCount + 1
        end if
        if s.date >= weekStart and s.date <= today then
            weekCount = weekCount + 1
            if s.duration <> invalid then weekMinutes = weekMinutes + int(s.duration)
        end if
    end for
    streak = calculateStreak(streakDates)

    starts30 = 0
    complete30 = 0
    cutoff30 = dateDaysAgo(29)
    for each s in sessions
        if s.date <> invalid and s.date >= cutoff30 and s.date <= today then
            starts30 = starts30 + 1
            if s.completed = true then complete30 = complete30 + 1
        end if
    end for
    rate30 = 0
    if starts30 > 0 then rate30 = int((complete30 * 100) / starts30)

    m.top.findNode("streak").text = stri(streak)
    m.top.findNode("week").text = stri(weekCount) + "/7"
    m.top.findNode("weekDetail").text = stri(weekMinutes) + " MIN"
    if starts30 > 0 then
        m.top.findNode("total").text = stri(rate30) + "%"
        m.top.findNode("completeRate").text = stri(complete30) + "/" + stri(starts30) + " STARTS"
    else
        m.top.findNode("total").text = "—"
        m.top.findNode("completeRate").text = "NO STARTS YET"
    end if

    m.top.findNode("ambientStreak").text = stri(streak)
    m.top.findNode("ambientWeek").text = stri(weekCount) + "/7"
    m.top.findNode("ambientMinutes").text = stri(weekMinutes)
    if starts30 > 0 then
        m.top.findNode("ambient30").text = stri(rate30) + "%"
    else
        m.top.findNode("ambient30").text = "—"
    end if

    renderAutoPilotAgenda(state)
end sub


sub renderAutoPilotAgenda(state as Object)
    agenda = invalid
    if state.autopilotAgenda <> invalid then agenda = state.autopilotAgenda
    if agenda = invalid and state.autoPilotAgenda <> invalid then agenda = state.autoPilotAgenda
    if agenda = invalid and state.agenda <> invalid then agenda = state.agenda

    times = [m.top.findNode("agendaTime1"), m.top.findNode("agendaTime2"), m.top.findNode("agendaTime3")]
    titles = [m.top.findNode("agendaTitle1"), m.top.findNode("agendaTitle2"), m.top.findNode("agendaTitle3")]
    metas = [m.top.findNode("agendaMeta1"), m.top.findNode("agendaMeta2"), m.top.findNode("agendaMeta3")]

    for i = 0 to 2
        times[i].text = ""
        titles[i].text = ""
        metas[i].text = ""
    end for

    if agenda = invalid then
        m.top.findNode("agendaStatus").text = "AUTOPILOT · READY"
        m.top.findNode("agendaStatus").color = "0x82909cff"
        titles[0].text = "TODAY'S FAMILY AGENDA"
        metas[0].text = "AutoPilot can publish a privacy-safe daily summary into NONZERO cloud state."
        return
    end if

    if agenda.date <> invalid and agenda.date <> "" and agenda.date <> rokuDateString() then
        m.top.findNode("agendaStatus").text = "AUTOPILOT · STALE"
        m.top.findNode("agendaStatus").color = "0xd58b38ff"
    else
        statusText = "AUTOPILOT · LIVE"
        if agenda.status <> invalid and agenda.status <> "" then statusText = "AUTOPILOT · " + ucase(agenda.status)
        m.top.findNode("agendaStatus").text = statusText
        m.top.findNode("agendaStatus").color = "0x55d67aff"
    end if

    items = agenda.items
    if items = invalid then items = []
    if items.count() = 0 then
        titles[0].text = "NO LOGISTICS ON DECK"
        metas[0].text = "Nothing requiring attention in today's published AutoPilot agenda."
        return
    end if

    limit = items.count()
    if limit > 3 then limit = 3
    for i = 0 to limit - 1
        item = items[i]
        if item.time <> invalid then times[i].text = item.time
        if item.title <> invalid then titles[i].text = item.title
        if item.meta <> invalid then metas[i].text = item.meta
    end for

    if items.count() > 3 then
        metas[2].text = metas[2].text + "  ·  +" + (items.count() - 3).toStr() + " MORE"
    end if
end sub

sub renderLive(p as Object, items as Object, currentIndex as Integer, mode as String, active as Object, pct as Integer)
    liveStatus = "active"
    if active.status <> invalid then liveStatus = lcase(active.status.toStr())
    if liveStatus = "paused" then
        m.top.findNode("stateBadge").text = "Ⅱ PAUSED"
        m.top.findNode("stateBadge").color = "0xd5a338ff"
    else
        m.top.findNode("stateBadge").text = "● LIVE"
        m.top.findNode("stateBadge").color = "0x55d67aff"
    end if
    m.top.findNode("session").text = ucase(p.name)
    detail = ucase(mode) + " · " + stri(pct) + "% COMPLETE"
    m.top.findNode("why").text = detail
    if currentIndex >= 0 and currentIndex < items.count() then
        m.top.findNode("currentMove").text = ucase(items[currentIndex][0])
        m.top.findNode("currentDetail").text = items[currentIndex][1]
    else
        m.top.findNode("currentMove").text = "FINISH STRONG"
        m.top.findNode("currentDetail").text = "All programmed movements are checked."
    end if
    ' One master NONZERO workout timer across every active Performance mode.
    m.top.findNode("timerLabel").text = "MASTER WORKOUT · ELAPSED"

    m.top.findNode("perfContext").text = "WORKOUT CLOCK"
    syncPerformanceClock(active)
    updateLiveTimer()
    renderPerformance(active, true)
end sub

sub renderComplete(p as Object, items as Object, completed as Object, mode as String, pct as Integer)
    m.top.findNode("stateBadge").text = "✓ WIN BANKED"
    m.top.findNode("stateBadge").color = "0xd58b38ff"
    m.top.findNode("session").text = "NONZERO DAY COMPLETE"
    dur = 0
    if completed.duration <> invalid then dur = completed.duration
    summary = ucase(p.name) + " · " + ucase(mode) + " · " + stri(dur) + " MIN"
    if completed.pain <> invalid then summary = summary + " · PAIN " + stri(completed.pain) + "/10"
    m.top.findNode("why").text = summary
    m.top.findNode("currentMove").text = "THE WORK IS DONE. THE IDENTITY STAYS."
    m.top.findNode("currentDetail").text = "Celebrate the win. Recover on purpose. Tomorrow is another vote for consistency."
    m.top.findNode("liveTimer").text = "✓ " + formatMinutes(dur)
    m.top.findNode("timerLabel").text = "TODAY'S WIN"
    m.top.findNode("perfContext").text = "VICTORY LAP · CONSISTENCY NEXT"
    renderPerformance(completed, false)
end sub

sub renderIdle(p as Object, items as Object, mode as String, pct as Integer)
    m.top.findNode("stateBadge").text = "READY"
    m.top.findNode("stateBadge").color = "0xd58b38ff"
    m.top.findNode("session").text = ucase(p.name)
    m.top.findNode("why").text = p.why
    m.top.findNode("liveTimer").text = "READY"
    m.top.findNode("timerLabel").text = "TODAY'S SESSION"
    if items.count() > 0 then
        m.top.findNode("currentMove").text = ucase(items[0][0])
        m.top.findNode("currentDetail").text = items[0][1]
    end if
    m.top.findNode("perfContext").text = "TODAY / WEEK"
    setPerformanceIdle()
end sub

sub setWallMode(mode as String)
    m.wallMode = mode
    m.top.currentWallMode = mode
    ambient = m.top.findNode("ambientGroup")
    performance = m.top.findNode("performanceGroup")
    night = m.top.findNode("nightGroup")
    deep = m.top.findNode("deepGroup")
    ambient.visible = false
    performance.visible = false
    if night <> invalid then night.visible = false
    if deep <> invalid then deep.visible = false

    if mode = "ambient" then
        ambient.visible = true
        m.top.findNode("ambientLine").visible = true
        if m.top.quoteContext = "accomplishment" then
            m.top.findNode("modePill").text = "VICTORY LAP"
        else if m.top.isScreensaver then
            m.top.findNode("modePill").text = "AMBIENT · SCREENSAVER"
        else
            m.top.findNode("modePill").text = "AMBIENT WALL"
        end if
    else if mode = "night" then
        if night <> invalid then night.visible = true
        m.top.findNode("ambientLine").visible = false
        m.top.findNode("modePill").text = "NIGHT"
    else if mode = "deep" then
        if deep <> invalid then deep.visible = true
        m.top.findNode("ambientLine").visible = false
        m.top.findNode("modePill").text = "DEEP PANEL PROTECT"
        updateDeepPanel()
    else
        performance.visible = true
        m.top.findNode("ambientLine").visible = false
        if mode = "performance" then m.top.findNode("modePill").text = "PERFORMANCE WALL"
    end if
end sub

function normalizeWallSchedule(raw as Object) as Object
    result = { enabled: true, ambient: "06:00", night: "20:30", deep: "01:00" }
    if raw = invalid then return result
    if raw.enabled <> invalid then result.enabled = raw.enabled
    if raw.ambient <> invalid and isTimeText(raw.ambient.toStr()) then result.ambient = raw.ambient.toStr()
    if raw.night <> invalid and isTimeText(raw.night.toStr()) then result.night = raw.night.toStr()
    if raw.deep <> invalid and isTimeText(raw.deep.toStr()) then result.deep = raw.deep.toStr()
    return result
end function

function isTimeText(v as String) as Boolean
    if len(v) <> 5 then return false
    if mid(v, 3, 1) <> ":" then return false
    h = val(left(v,2))
    n = val(right(v,2))
    return h >= 0 and h <= 23 and n >= 0 and n <= 59
end function

function timeTextToMinutes(v as String) as Integer
    if not isTimeText(v) then return 0
    return int(val(left(v,2))) * 60 + int(val(right(v,2)))
end function

function elapsedSince(nowMin as Integer, startMin as Integer) as Integer
    d = nowMin - startMin
    if d < 0 then d = d + 1440
    return d
end function

function getScheduledWallMode() as String
    sched = m.wallSchedule
    if sched = invalid or sched.enabled = false then return "ambient"
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    nowMin = dt.GetHours() * 60 + dt.GetMinutes()
    a = elapsedSince(nowMin, timeTextToMinutes(sched.ambient))
    n = elapsedSince(nowMin, timeTextToMinutes(sched.night))
    d = elapsedSince(nowMin, timeTextToMinutes(sched.deep))
    if a <= n and a <= d then return "ambient"
    if n <= a and n <= d then return "night"
    return "deep"
end function

sub applyScheduledTransition()
    if m.currentActive <> invalid or m.holdActive = true then return
    target = getScheduledWallMode()
    if target <> m.wallMode then setWallMode(target)
end sub

sub renderAmbient(p as Object, completed as Object)
    workoutGroup = m.top.findNode("ambientWorkoutGroup")
    countdownGroup = m.top.findNode("surgeryCountdownGroup")
    celebration = m.top.findNode("celebrationGlow")
    hasCountdown = countdownGroup <> invalid and countdownGroup.visible = true

    if completed <> invalid and completed.completed = true then
        if celebration <> invalid then celebration.visible = true
        if m.top.findNode("ambientRightAccent") <> invalid then m.top.findNode("ambientRightAccent").color = "0xd58b38ff"
        m.top.findNode("modePill").text = "VICTORY LAP"
        if hasCountdown then
            m.top.findNode("surgeryTodayStatus").text = "TODAY · COMPLETE ✓"
            m.top.findNode("surgeryTodayStatus").color = "0xd58b38ff"
            m.top.findNode("surgeryTodayWorkout").text = ucase(p.name)
            m.top.findNode("surgeryDirective").text = "WIN BANKED. RECOVER WELL. PROTECT TOMORROW'S CONSISTENCY."
        else
            if workoutGroup <> invalid then workoutGroup.visible = true
            m.top.findNode("ambientTodayLabel").text = "TODAY · COMPLETE ✓"
            m.top.findNode("ambientTodayLabel").color = "0xd58b38ff"
            m.top.findNode("ambientToday").text = "NONZERO DAY LOCKED IN"
            dur = 0
            if completed.duration <> invalid then dur = int(completed.duration)
            m.top.findNode("ambientTodayDetail").text = stri(dur) + " MINUTES · WIN BANKED · RECOVER WELL · STACK ANOTHER TOMORROW"
        end if
    else
        if celebration <> invalid then celebration.visible = false
        if m.top.findNode("ambientRightAccent") <> invalid then m.top.findNode("ambientRightAccent").color = "0x55d67aaa"
        if hasCountdown then
            m.top.findNode("surgeryTodayStatus").text = "TODAY · READY"
            m.top.findNode("surgeryTodayStatus").color = "0x55d67aff"
            m.top.findNode("surgeryTodayWorkout").text = ucase(p.name)
        else
            if workoutGroup <> invalid then workoutGroup.visible = true
            m.top.findNode("ambientTodayLabel").text = "TODAY · READY"
            m.top.findNode("ambientTodayLabel").color = "0x55d67aff"
            m.top.findNode("ambientToday").text = ucase(p.name)
            m.top.findNode("ambientTodayDetail").text = p.why
        end if
    end if
end sub

sub renderSurgeryCountdown(state as Object, p as Object, completed as Object)
    grp = m.top.findNode("surgeryCountdownGroup")
    workout = m.top.findNode("ambientWorkoutGroup")
    if grp = invalid then return
    surgery = invalid
    if state.surgeryPlan <> invalid then surgery = state.surgeryPlan
    dateText = ""
    if surgery <> invalid and surgery.date <> invalid then dateText = surgery.date.toStr()
    if len(dateText) <> 10 then
        grp.visible = false
        if workout <> invalid then workout.visible = true
        return
    end if
    days = daysBetweenDates(rokuDateString(), dateText)
    grp.visible = true
    if workout <> invalid then workout.visible = false
    phase = preOpPhase(days)
    if days > 0 then
        m.top.findNode("surgeryDays").text = stri(days)
        if days = 1 then m.top.findNode("surgeryDaysUnit").text = "DAY" else m.top.findNode("surgeryDaysUnit").text = "DAYS"
    else if days = 0 then
        m.top.findNode("surgeryDays").text = "0"
        m.top.findNode("surgeryDaysUnit").text = "TODAY"
    else
        m.top.findNode("surgeryDays").text = stri(abs(days))
        m.top.findNode("surgeryDaysUnit").text = "DAYS POST"
    end if
    m.top.findNode("surgeryPhase").text = phase
    m.top.findNode("surgeryDateText").text = "SURGERY · " + dateText
    m.top.findNode("surgeryTodayWorkout").text = ucase(p.name)
    if days > 42 then
        m.top.findNode("surgeryDirective").text = "BUILD THE BASE · STACK STRENGTH + AEROBIC CAPACITY · PROTECT THE HIP"
    else if days > 14 then
        m.top.findNode("surgeryDirective").text = "CONSISTENCY BLOCK · KEEP SHOWING UP · ARRIVE FIT, NOT BEAT UP"
    else if days > 3 then
        m.top.findNode("surgeryDirective").text = "ARRIVE READY · MAINTAIN FITNESS · PRIORITIZE RECOVERY + CONFIDENCE"
    else if days >= 0 then
        m.top.findNode("surgeryDirective").text = "PROTECT THE WORK · RECOVER · FOLLOW YOUR SURGICAL TEAM'S INSTRUCTIONS"
    else
        m.top.findNode("surgeryDirective").text = "POST-OP MODE · FOLLOW YOUR CLINICAL PLAN BEFORE RESUMING TRAINING"
    end if
end sub

function preOpPhase(days as Integer) as String
    if days < 0 then return "POST-OP"
    if days = 0 then return "SURGERY DAY"
    if days <= 3 then return "FINAL APPROACH"
    if days <= 14 then return "ARRIVE READY"
    if days <= 42 then return "CONSISTENCY BLOCK"
    if days <= 84 then return "BUILD CAPACITY"
    return "BUILD BASE"
end function

function daysBetweenDates(fromDate as String, toDate as String) as Integer
    return dateSerial(toDate) - dateSerial(fromDate)
end function

function dateSerial(v as String) as Integer
    if len(v) < 10 then return 0
    y = int(val(left(v,4)))
    m = int(val(mid(v,6,2)))
    d = int(val(mid(v,9,2)))
    if m <= 2 then y = y - 1 : m = m + 12
    return (365 * y) + int(y / 4) - int(y / 100) + int(y / 400) + int((153 * (m - 3) + 2) / 5) + d
end function

sub onCompletionHold()
    m.holdActive = false
    if m.lastState <> invalid then renderState(m.lastState)
end sub

sub renderPerformance(rec as Object, isLive as Boolean)
    metrics = invalid
    if rec.liveMetrics <> invalid then metrics = rec.liveMetrics
    if metrics = invalid and rec.metrics <> invalid then metrics = rec.metrics
    if metrics = invalid and rec.postMetrics <> invalid then metrics = rec.postMetrics
    if metrics = invalid then metrics = {}

    hr = firstNumber(metrics, ["heartRate", "hr", "avgHr"])
    watts = firstNumber(metrics, ["watts", "power", "avgWatts"])
    calories = firstNumber(metrics, ["calories", "kcal", "cals"])
    cadence = firstNumber(metrics, ["cadence", "rpm", "rate"])
    distance = firstNumber(metrics, ["distance", "meters"])

    if hr <= 0 and rec.avgHr <> invalid then hr = int(rec.avgHr)
    if watts <= 0 and rec.avgWatts <> invalid then watts = int(rec.avgWatts)
    if calories <= 0 and rec.calories <> invalid then calories = int(rec.calories)
    if cadence <= 0 and rec.rate <> invalid then cadence = int(rec.rate)
    if distance <= 0 and rec.distance <> invalid then distance = int(rec.distance)

    m.top.findNode("metric1Value").text = metricText(hr)
    m.top.findNode("metric1Unit").text = "BPM"
    m.top.findNode("metric1Label").text = "HEART RATE"
    m.top.findNode("metric2Value").text = metricText(calories)
    m.top.findNode("metric2Unit").text = "KCAL"
    m.top.findNode("metric2Label").text = "CALORIES"
    if watts > 0 then
        m.top.findNode("metric3Value").text = metricText(watts)
        m.top.findNode("metric3Unit").text = "W"
        m.top.findNode("metric3Label").text = "OUTPUT"
    else
        m.top.findNode("metric3Value").text = metricText(cadence)
        m.top.findNode("metric3Unit").text = "RPM"
        m.top.findNode("metric3Label").text = "CADENCE"
    end if
    m.top.findNode("metric4Value").text = metricText(distance)
    m.top.findNode("metric4Unit").text = "M"
    m.top.findNode("metric4Label").text = "DISTANCE"
end sub

sub setPerformanceIdle()
    m.top.findNode("metric1Value").text = "—"
    m.top.findNode("metric1Unit").text = ""
    m.top.findNode("metric1Label").text = "HEART RATE"
    m.top.findNode("metric2Value").text = "—"
    m.top.findNode("metric2Unit").text = ""
    m.top.findNode("metric2Label").text = "CALORIES"
    m.top.findNode("metric3Value").text = "—"
    m.top.findNode("metric3Unit").text = ""
    m.top.findNode("metric3Label").text = "CADENCE"
    m.top.findNode("metric4Value").text = "—"
    m.top.findNode("metric4Unit").text = ""
    m.top.findNode("metric4Label").text = "DISTANCE"
end sub

sub onHeartbeat()
    ' main.brs supplies this heartbeat every second. This keeps schedule transitions
    ' and clock painting independent of SceneGraph Timer reliability.
    updateNightClockNodes()
    applyScheduledTransition()
    if m.wallMode = "deep" then updateDeepPanel()
    ensureKeepAwakePlayback()
    updateLiveTimer()
end sub

sub updateNightClockNodes()
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    h = dt.GetHours()
    mins = dt.GetMinutes()
    suffix = "AM"
    displayH = h
    if h >= 12 then suffix = "PM"
    if displayH = 0 then displayH = 12
    if displayH > 12 then displayH = displayH - 12
    mm = mins.toStr()
    if mins < 10 then mm = "0" + mm

    headerClock = m.top.findNode("nightHeaderClock")
    if headerClock <> invalid then headerClock.text = displayH.toStr() + ":" + mm + " " + suffix
    shortDate = monthShortName(dt.GetMonth()) + " " + dt.GetDayOfMonth().toStr() + ", " + dt.GetYear().toStr()
    headerDate = m.top.findNode("nightHeaderDate")
    if headerDate <> invalid then headerDate.text = shortDate
    fullDate = monthLongName(dt.GetMonth()) + " " + dt.GetDayOfMonth().toStr() + ", " + dt.GetYear().toStr()
    nd = m.top.findNode("nightDate")
    if nd <> invalid then nd.text = ucase(fullDate)

    ht = int(displayH / 10)
    ho = displayH mod 10
    mt = int(mins / 10)
    mo = mins mod 10
    setDigitalPoster("nightHourTens", ht, displayH >= 10)
    setDigitalPoster("nightHourOnes", ho, true)
    setDigitalPoster("nightMinuteTens", mt, true)
    setDigitalPoster("nightMinuteOnes", mo, true)
    ap = m.top.findNode("nightAmPm")
    if ap <> invalid then ap.text = suffix

    deepClock = m.top.findNode("deepClock")
    if deepClock <> invalid then deepClock.text = displayH.toStr() + ":" + mm + " " + suffix
    deepDate = m.top.findNode("deepDate")
    if deepDate <> invalid then deepDate.text = shortDate
end sub

sub setDigitalPoster(id as String, digit as Integer, showIt as Boolean)
    p = m.top.findNode(id)
    if p = invalid then return
    p.visible = showIt
    if showIt then p.uri = "pkg:/images/digital/" + digit.toStr() + ".png"
end sub

function monthShortName(mo as Integer) as String
    a = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"]
    if mo < 1 or mo > 12 then return ""
    return a[mo-1]
end function

function monthLongName(mo as Integer) as String
    a = ["JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"]
    if mo < 1 or mo > 12 then return ""
    return a[mo-1]
end function

sub startKeepAwakeVideo()
    if m.keepAwakeVideo = invalid then return
    content = CreateObject("roSGNode", "ContentNode")
    content.url = "pkg:/videos/keepawake.mp4"
    content.streamFormat = "mp4"
    m.keepAwakeVideo.content = content
    m.keepAwakeVideo.control = "play"
end sub

sub ensureKeepAwakePlayback()
    if m.keepAwakeVideo = invalid then return
    st = m.keepAwakeVideo.state
    if st = "stopped" or st = "finished" or st = "error" then startKeepAwakeVideo()
end sub

sub onKeepAwakeState()
    ensureKeepAwakePlayback()
end sub

sub updateDeepPanel()
    if m.wallMode <> "deep" then return
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    minuteKey = dt.GetHours() * 60 + dt.GetMinutes()
    if minuteKey = m.deepLastMinute then return
    m.deepLastMinute = minuteKey
    cluster = m.top.findNode("deepStatusCluster")
    if cluster = invalid then return
    positions = [[92,90],[1390,92],[88,890],[1375,880],[730,116],[724,886],[128,472],[1365,472]]
    idx = minuteKey mod positions.count()
    cluster.translation = positions[idx]
end sub

sub onClock()
    updateNightClockNodes()
    ' Keep this heartbeat deliberately simple: it must never throw, because the
    ' startup, quote rotation, and cloud polling timers are started immediately
    ' after the first call to onClock(). v4.1.1 incorrectly passed the numeric
    ' weekday directly to UCase(), aborting init after the first clock paint.
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    h = dt.GetHours(): min = dt.GetMinutes()
    suffix = "AM": displayH = h
    if h >= 12 then suffix = "PM"
    if displayH = 0 then displayH = 12
    if displayH > 12 then displayH = displayH - 12
    mm = stri(min): if min < 10 then mm = "0" + mm
    m.top.findNode("clock").text = stri(displayH) + ":" + mm + " " + suffix

    weekdays = ["SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"]
    dow = dt.GetDayOfWeek()
    dayName = ""
    if dow >= 0 and dow <= 6 then dayName = weekdays[dow]
    dateText = dayName + " · " + stri(dt.GetMonth()) + "/" + stri(dt.GetDayOfMonth()) + "/" + stri(dt.GetYear())
    m.top.findNode("date").text = dateText
    giantTime = stri(displayH) + ":" + mm + " " + suffix
    nightClock = m.top.findNode("nightClock")
    deepClock = m.top.findNode("deepClock")
    if nightClock <> invalid then nightClock.text = giantTime
    if deepClock <> invalid then deepClock.text = giantTime
    nightDate = m.top.findNode("nightDate")
    deepDate = m.top.findNode("deepDate")
    if nightDate <> invalid then nightDate.text = dateText
    if deepDate <> invalid then deepDate.text = dateText
    applyScheduledTransition()
    updateLiveTimer()
end sub

function performanceMotivationPhrases(elapsedSec as Integer, completeCount as Integer, totalCount as Integer) as Object
    ratio = 0.0
    if totalCount > 0 then ratio = completeCount / totalCount

    if ratio >= 0.8 or elapsedSec >= 2700 then
        return ["FINISH STRONG", "EMPTY THE TANK", "CLOSE IT OUT", "NO COASTING", "MAKE IT COUNT", "ONE MORE PUSH"]
    else if ratio >= 0.35 or elapsedSec >= 900 then
        return ["KEEP PUSHING", "STAY ON IT", "DON'T COAST", "KEEP MOVING", "DO THE WORK", "STACK THE WIN", "HOLD THE LINE"]
    else
        return ["SETTLE IN", "BUILD MOMENTUM", "START STRONG", "FIND YOUR RHYTHM", "KEEP MOVING", "LOCK IN", "DO THE WORK"]
    end if
end function

sub updatePerformanceMotivation(active as Object, elapsedSec as Integer)
    label = m.top.findNode("motivationPhrase")
    if label = invalid or active = invalid then return

    completeCount = 0
    totalCount = 0
    if active.checks <> invalid and type(active.checks) = "roArray" then
        totalCount = active.checks.count()
        for each c in active.checks
            if c = true then completeCount = completeCount + 1
        end for
    end if

    now = CreateObject("roDateTime").AsSeconds()

    if m.motivationLastProgressCount >= 0 and completeCount > m.motivationLastProgressCount then
        if totalCount > 0 and completeCount >= totalCount then
            m.motivationFlashText = "WORK COMPLETE · FINISH STRONG"
        else if completeCount >= 2 then
            m.motivationFlashText = "KEEP STACKING"
        else
            m.motivationFlashText = "ONE DOWN"
        end if
        m.motivationFlashUntil = now + 5
    end if
    m.motivationLastProgressCount = completeCount

    if m.motivationFlashUntil > now and m.motivationFlashText <> "" then
        label.text = m.motivationFlashText
        return
    end if

    phrases = performanceMotivationPhrases(elapsedSec, completeCount, totalCount)
    if phrases.count() = 0 then return

    if m.motivationLastRotate = 0 then
        m.motivationLastRotate = now
        m.motivationIndex = 0
    else if now - m.motivationLastRotate >= 18 then
        m.motivationIndex = (m.motivationIndex + 1) mod phrases.count()
        m.motivationLastRotate = now
    end if

    if m.motivationIndex >= phrases.count() then m.motivationIndex = 0
    label.text = phrases[m.motivationIndex]
end sub

sub syncPerformanceClock(active as Object)
    if active = invalid then return
    t = active.timer
    if t = invalid then return

    sid = ""
    if active.sessionId <> invalid then sid = active.sessionId.toStr()
    stamp = 0
    if active.timerUpdatedAt <> invalid then stamp = val(active.timerUpdatedAt.toStr())
    running = false
    if t.running = true then running = true

    needsSync = sid <> m.performanceClockSession or stamp <> m.performanceClockStamp or running <> m.performanceClockRunning
    if needsSync then
        elapsed = 0.0
        if t.elapsedMs <> invalid then elapsed = val(t.elapsedMs.toStr())
        if running and t.startedAt <> invalid then
            nowDt = CreateObject("roDateTime")
            approxNowMs = nowDt.AsSeconds() * 1000.0
            delta = approxNowMs - val(t.startedAt.toStr())
            if delta > 0 and delta < 86400000 then elapsed = elapsed + delta
        end if
        m.performanceClockSession = sid
        m.performanceClockStamp = stamp
        m.performanceClockRunning = running
        m.performanceClockBaseMs = elapsed
        m.performanceClockSpan.Mark()
    end if
end sub

sub updateLiveTimer()
    if m.currentActive = invalid then return
    syncPerformanceClock(m.currentActive)
    elapsed = m.performanceClockBaseMs
    if m.performanceClockRunning then elapsed = elapsed + m.performanceClockSpan.TotalMilliseconds()
    m.top.findNode("liveTimer").text = formatMillis(elapsed)
    updatePerformanceMotivation(m.currentActive, int(elapsed / 1000))
    updateLapDisplay(m.currentActive, elapsed)
end sub

sub updateLapDisplay(active as Object, masterElapsed as Dynamic)
    lapReadout = m.top.findNode("lapReadout")
    lapMeta = m.top.findNode("lapMeta")
    lapMetrics = m.top.findNode("lapMetrics")
    lapLabel = m.top.findNode("lapLabel")
    if lapReadout = invalid then return

    lapStart = 0
    if active.lapStartElapsedMs <> invalid then lapStart = val(active.lapStartElapsedMs.toStr())
    lapElapsed = masterElapsed - lapStart
    if lapElapsed < 0 then lapElapsed = 0

    laps = []
    if active.laps <> invalid and type(active.laps) = "roArray" then laps = active.laps

    lapReadout.text = formatMillis(lapElapsed)
    lapMeta.text = "LAP " + (laps.count() + 1).toStr() + " · LIVE"
    lapMetrics.text = "RPM — · WATTS —"

    if laps.count() > 0 then
        last = laps[laps.count() - 1]
        rpmTxt = "—"
        wattsTxt = "—"
        if last.rpm <> invalid and val(last.rpm.toStr()) > 0 then rpmTxt = int(val(last.rpm.toStr())).toStr()
        if last.watts <> invalid and val(last.watts.toStr()) > 0 then wattsTxt = int(val(last.watts.toStr())).toStr()
        lapMetrics.text = "LAST · " + rpmTxt + " RPM · " + wattsTxt + " W"
    end if

    isBike = false
    if active.type <> invalid then
        typ = lcase(active.type.toStr())
        if typ = "bike" or typ = "erg" then isBike = true
    end if

    showLap = isBike or laps.count() > 0
    lapGroup = m.top.findNode("lapGroup")
    if lapGroup <> invalid then lapGroup.visible = showLap
    lapLabel.visible = showLap
    lapReadout.visible = showLap
    lapMeta.visible = showLap
    lapMetrics.visible = showLap
end sub

sub rotateQuote()
    m.quoteIndex = (m.quoteIndex + 1) mod m.quotes.count()
    q = m.quotes[m.quoteIndex]
    m.top.findNode("quote").text = q
    m.top.findNode("ambientQuote").text = q
    ' Ambient quote transition is owned by source/main.brs.
end sub

function firstNumber(o as Object, keys as Object) as Integer
    if o = invalid then return 0
    for each k in keys
        if o[k] <> invalid then
            v = val(o[k].toStr())
            if v > 0 then return int(v)
        end if
    end for
    return 0
end function

function metricText(v as Integer) as String
    if v <= 0 then return "—"
    return stri(v)
end function

function formatMillis(ms as Dynamic) as String
    if ms < 0 then ms = 0
    totalSec = int(ms / 1000)
    hrs = int(totalSec / 3600)
    mins = int((totalSec mod 3600) / 60)
    secs = totalSec mod 60
    hund = int((ms mod 1000) / 10)

    mm = mins.toStr(): if mins < 10 then mm = "0" + mm
    ss = secs.toStr(): if secs < 10 then ss = "0" + ss
    hh = hund.toStr(): if hund < 10 then hh = "0" + hh

    if hrs > 0 then
        hs = hrs.toStr(): if hrs < 10 then hs = "0" + hs
        return hs + ":" + mm + ":" + ss + "." + hh
    end if
    return mm + ":" + ss + "." + hh
end function

function formatMinutes(v as Dynamic) as String
    mins = int(val(v.toStr()))
    if mins < 0 then mins = 0
    return stri(mins) + ":00"
end function

function isDigits(s as String) as Boolean
    if len(s) = 0 then return false
    for i = 1 to len(s)
        c = mid(s, i, 1)
        if c < "0" or c > "9" then return false
    end for
    return true
end function

function rokuDateString() as String
    d = CreateObject("roDateTime"): d.ToLocalTime()
    y = d.GetYear().toStr(): mo = d.GetMonth().toStr(): da = d.GetDayOfMonth().toStr()
    if d.GetMonth() < 10 then mo = "0" + mo
    if d.GetDayOfMonth() < 10 then da = "0" + da
    return y + "-" + mo + "-" + da
end function

function dateDaysAgo(days as Integer) as String
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    d.FromSeconds(d.AsSeconds() - (days * 86400))
    d.ToLocalTime()
    y = d.GetYear().toStr(): mo = d.GetMonth().toStr(): da = d.GetDayOfMonth().toStr()
    if d.GetMonth() < 10 then mo = "0" + mo
    if d.GetDayOfMonth() < 10 then da = "0" + da
    return y + "-" + mo + "-" + da
end function

function weekStartDate() as String
    d = CreateObject("roDateTime"): d.ToLocalTime()
    dow = d.GetDayOfWeek()
    offset = dow - 1
    if offset < 0 then offset = 6
    d.FromSeconds(d.AsSeconds() - (offset * 86400))
    d.ToLocalTime()
    y = d.GetYear().toStr(): mo = d.GetMonth().toStr(): da = d.GetDayOfMonth().toStr()
    if d.GetMonth() < 10 then mo = "0" + mo
    if d.GetDayOfMonth() < 10 then da = "0" + da
    return y + "-" + mo + "-" + da
end function

function calculateStreak(set as Object) as Integer
    d = CreateObject("roDateTime"): d.ToLocalTime()
    today = rokuDateString()
    if set[today] = invalid then d.FromSeconds(d.AsSeconds() - 86400): d.ToLocalTime()
    n = 0
    for i = 0 to 3650
        y = d.GetYear().toStr(): mo = d.GetMonth().toStr(): da = d.GetDayOfMonth().toStr()
        if d.GetMonth() < 10 then mo = "0" + mo
        if d.GetDayOfMonth() < 10 then da = "0" + da
        k = y + "-" + mo + "-" + da
        if set[k] = invalid then exit for
        n = n + 1
        d.FromSeconds(d.AsSeconds() - 86400): d.ToLocalTime()
    end for
    return n
end function

function getFlare() as Object
    return [["BikeErg", "5–10 min very easy if comfortable"], ["Upper body", "Easy push-ups, rows or floor press"], ["Avoid today", "Loaded lower-body work / deep flexion"], ["Win condition", "10 calm minutes and stop"]]
end function

function getProgram(dow as Integer) as Object
    programs = {
        "1": {name:"Recovery", why:"Keep the habit while giving the hip a low-stress day.", full:[["BikeErg","10–15 min very easy"],["Hip abduction","1–2 × 8 each side"],["Band row","2 × 12"],["Breathing","2 min relaxed"]], minimum:[["BikeErg","5–10 min very easy"],["Upper-body band work","Easy until 10:00"]]},
        "2": {name:"Strength A — Upper + Hinge", why:"Build strength without forcing deep hip flexion.", full:[["BikeErg warm-up","4 min easy"],["Elevated KB deadlift","53 lb — 3 × 8"],["Push-ups","3 × 8–12"],["Supported KB row","35 lb — 3 × 10 each"],["Farmer carry","2 × 35 lb — 3 × 30 sec"]], minimum:[["BikeErg","2 min easy"],["Elevated KB deadlift","2 × 8"],["Push-ups","2 × 8–12"],["KB row","2 × 8 each"],["BikeErg","Easy until 10:00"]]},
        "3": {name:"BikeErg — Aerobic", why:"Build cardiovascular fitness with minimal impact.", full:[["Easy spin","5 min"],["Steady aerobic ride","15–20 min"],["Easy spin","5 min"]], minimum:[["BikeErg","10 min continuous"]]},
        "4": {name:"Strength B — Prehab + Upper", why:"Maintain strength and train tolerable hip-supporting musculature.", full:[["BikeErg warm-up","4 min easy"],["High sit-to-stand","3 × 10"],["Pull-ups","3 × 2–3"],["KB floor press","3 × 8–10"],["Pallof press","2 × 10 each"]], minimum:[["BikeErg","2 min"],["High sit-to-stand","2 × 8"],["Pull-ups","2 × 2"],["KB floor press","2 × 8"],["Pallof press","2 × 8"]]},
        "5": {name:"BikeErg — Aerobic", why:"Add aerobic volume without accumulating painful walking mileage.", full:[["Easy spin","5 min"],["Steady aerobic ride","20–25 min"],["Easy spin","5 min"]], minimum:[["BikeErg","10 min easy/moderate"]]},
        "6": {name:"Strength — Alternating", why:"Third weekly strength exposure while keeping workload manageable.", full:[["BikeErg warm-up","4 min"],["Elevated KB deadlift","2 × 8"],["Push-ups","2 × 10–15"],["Pull-ups","2 × 2–3"],["Farmer carry","3 × 30 sec"]], minimum:[["BikeErg","2 min"],["Push-ups","2 × 10"],["KB row","2 × 8 each"],["Farmer carry","2 × 30 sec"],["BikeErg","Until 10:00"]]},
        "7": {name:"Long BikeErg", why:"Your main low-impact endurance builder.", full:[["Easy spin","5 min"],["Steady BikeErg","30–35 min"],["Easy spin","5 min"],["Optional","Add 5 min if hip feels good"]], minimum:[["BikeErg","10 min easy/moderate"]]}
    }
    key = (dow + 1).toStr()
    if programs[key] <> invalid then return programs[key]
    return programs["1"]
end function
