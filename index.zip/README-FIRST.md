NONZERO Connected Coach — Pi 7.12.0 / Phone 3.56 / Worker 5.14

This release updates all three components. Keep your existing private key, KV namespace, pairings and raw recordings.

1. Cloudflare: create a D1 database named nonzero-coach, add a D1 binding named NONZERO_COACH to your existing NonZero Worker, and deploy the complete Worker 5.14 file in cloud/. Existing NONZERO_STATE KV stays bound. Tables initialize automatically. Do not bind this to your AutoPilot database. See README-CONNECTED-COACH.md.
2. Replace your existing phone page with the complete Phone 3.56 HTML in phone/. Keep the same serving URL/origin to retain local settings. Confirm 3.56 and open Coach. The old filenames inside this Pi bundle are compatibility paths; the files themselves contain the current complete versions.
3. Save NONZERO-Pi-v7.12.0-CONNECTED-COACH.zip in Downloads and run your existing Update NONZERO desktop shortcut. Confirm 7.12.0. No new shortcut or PM5 pairing is needed.

All five upgrades are described in README-CONNECTED-COACH.md. The detailed test plan/results and remaining physical acceptance checks are in QA/TEST-PLAN-v7.12.0.md and QA/TEST-RESULTS-v7.12.0.json.

Missing D1 does not stop ordinary workouts or Pi-local check-ins. Shared coaching remains visibly pending until configured; never interpret a local save as cloud acknowledgement.
