# Connected Coach — Pi 7.12.0 / Phone 3.56 / Worker 5.14

## Install once

Use the three complete components in this release. Preserve the existing Worker name/URL, NONZERO_STATE KV binding and private key. Create a separate D1 database, nonzero-coach. In the existing NonZero Worker's Bindings, add a D1 database binding whose variable name is exactly NONZERO_COACH and select that database. Deploy the complete Worker 5.14 JavaScript. No SQL or cron setup is required: two small indexed tables initialize automatically on first use. Existing Concept2 and weight-import integrations remain intact. Do not repurpose the AutoPilot D1 database.

Worker /health should report version 5.14, sharedCoaching true and coachDatabaseBound true. This checks configuration, not actual end-to-end storage. Open the phone's Coach page, save a harmless commitment and verify the same value appears on Wall. Replace the phone HTML at the existing serving URL/origin and confirm 3.56; this retains local configuration when the origin stays the same. Install the Pi ZIP with your existing desktop updater and confirm 7.12.0.

Official binding guide: https://developers.cloudflare.com/d1/get-started/

## 1. Start and capture confirmation

Coach → Start and capture confirmation checks PM5 movement, durable recorder samples, Wall Performance and phone acknowledgement separately. On the Pi, it reads actual local SQLite/raw timestamps rather than treating changing display values as storage proof. Stored samples/s is observed over ten seconds; it is not a promise that the hardware delivers every possible PM5 field. USB and BLE retain their existing independent capture paths.

A session's observed startup stages stay recorded while a workout is held for strength work. Current signal/storage freshness and timestamps remain separate. An idle PM5 during a held workout is expected. Missing/stale Wall status is never marked confirmed. Phone data is explicitly the latest Wall report, not a direct phone-to-PM5 measurement. Refresh and retry sync rechecks state/pending starts; it does not invent motion or restart the Pi. Diagnosis export contains bounded transition history on the Pi and the latest remote chain on the phone, without endpoint credentials or private keys.

## 2. One shared phone-and-Wall coach

The existing phone app now has Coach alongside Today, Week, History and Settings. Pi-local QR access uses the same UI, core calculations and schema. Weight goal is 185 on both screens, with the separate personal sub-220 surgery goal. Daily actions, known intake, plan/recovery settings, personal commitments, strength records and review decisions share one document.

Phone operations save immediately to local storage; Pi operations save to durable SQLite. Pending operations survive reloads and updates. Shared sync uses field versions, idempotent operation IDs and a D1 compare-and-swap revision check, so concurrent edits to different fields merge even across Worker instances. Same-field disagreement stays pending and requires Keep pending edits or Discard pending edits. A general workout/weight state save cannot overwrite the authoritative coaching document. Account-bound journals prevent uploading another identity's pending data. The first account binding migrates existing Pi check-ins; subsequent accounts get separate journals. Rejected/invalid operations remain recoverable instead of being reported as successfully synced.

Old phone pages must reload before editing shared Pi records. Raw recording does not depend on this coach or cloud availability. If shared D1 is unavailable, existing workout state still returns, check-ins remain local/pending, and the UI explains the problem.

## 3. Strength alongside weight

Log a completed set's date, movement, precise variation/setup, external load in pounds or bodyweight repetitions, repetitions, RPE, pain and recovery notes. This is a record of completed work, not an exercise prescription. Comparable external-load sets use a simple estimated set index, load × (1 + repetitions/30); bodyweight repetitions are kept separate. This is descriptive and does not measure muscle mass.

A trend needs four distinct dates spanning at least fourteen days, the same movement/variation/mode, 1–12 repetitions, RPE 7–9 with comparable median effort, pain no higher than 3, and a recent observation. Changes of +3% or -5% label improving or declining; these are app heuristics, not clinically validated thresholds. Objective decline reduces planning pace and blocks trend-driven tightening. Older/less comparable data remains in history without producing a confident trend. Weight and comparable strength feedback appear together on Wall and in the phone Coach. Comparisons restart with the postoperative phase; presurgical sets do not prove postoperative gains.

## 4. Weekly trend-based reviews

The coach requires at least 21 days, 12 dated weight readings and 14 known daily intake totals, including coverage at both ends of the period. It uses the median of weight-change slopes separated by at least seven days and shows an empirical range with a minimum noise margin. This is not a statistical confidence interval. Missing intake is unknown; low logged intake triggers review rather than being silently discarded to improve the forecast.

An observed maintenance estimate combines logged intake and the approximate energy equivalent of the observed trend. This is not the NIH dynamic metabolism model and cannot establish true expenditure or a measured deficit. Scale shifts, incomplete logs and changing physiology can bias it. A suggested maintenance revision is capped at 100 kcal/day per weekly review and requires an explicit Apply reviewed estimate action. Keep current estimate is also recorded. No repeat adjustment occurs for seven days. A recent positive trend can show a range of weeks to the next target, never a guaranteed deadline.

Healing, stale/insufficient data, low fueling, rapid loss or declining strength block inappropriate adjustments. Postoperative weight confirmation, milestones, strength comparisons and calibration use the new phase's data; preoperative averages do not become postoperative achievements. Food/activity clearance and reviewed recovery maintenance remain separate requirements. Resistance clearance is separate from nutrition clearance. Reaching 185 moves the coach toward maintenance and approved strength/recovery work.

## 5. Personal behavior commitments

Choose one primary commitment: meal planning, protein at meals, or approved movement/PT. Attach it to breakfast, lunch, dinner or an available AutoPilot window. Enter your own reason, a smaller busy-day fallback and a meaningful nonfood milestone reward. Log time, pain/restrictions or a forgotten cue as barriers, or say Useful cue / Make it smaller / Change the cue. Prompts adapt to those choices and recent follow-through; they do not punish missed actions or equate exercise calories with permission to eat. Pain feedback redirects toward restrictions and food planning rather than extra movement.

The calendar anchor uses the same AutoPilot opportunity calculation on phone, Wall and local QR page. The UI limits long Wall text to preserve readability; full wording remains available in the phone Coach. This is a transparent rule-based behavior tool, not evidence that an algorithm has learned a medical treatment or guaranteed an outcome.

## Noom handoff

Noom is the preferred meal log in this personal build. Keep individual meals there; Coach accepts one daily food-calorie total with source and complete-day labels. Use calories consumed, not calories remaining or an exercise-adjusted allowance. Infrequent/partial logging stays unknown for calorie review, and partial Noom totals do not trigger a low-fueling conclusion or a maintenance adjustment. Existing explicitly entered daily totals remain distinguishable from Noom entries.

No Noom account connection or automatic meal import is claimed. Current Noom support describes step/weight compatibility; an end-to-end nutrition feed has not been verified. Noom also offers a personal data export request, but an actual export sample is needed before implementing a reliable parser/reconciliation path. References: https://www.noom.com/support/faqs/troubleshooting/syncing-and-compatibility/2025/10/syncing-noom-with-apps-on-ios/ and https://www.noom.com/support/faqs/privacy-and-data/2025/10/how-to-export-and-delete-your-noom-data/ .

## Data, costs and limits

Normal state polling frequency and the single-key KV read pattern are unchanged. When D1 is bound, each existing successful state read adds one indexed D1 document read. It does not add a second general HTTP polling loop. Routine state reads write nothing to D1. Coach writes occur for user edits; a phone acknowledgement writes once per new session. Opening Coach/diagnostics, foreground checks and failures can add bounded requests; retry backoff caps at thirty seconds. Wall captures stay local and raw packet storage is unchanged.

D1 and Worker usage share the account's billing plan; this is not a guarantee about total charges from other apps. Current pricing: https://developers.cloudflare.com/d1/platform/pricing/ . Check the account's actual usage after deployment.

Coaching history is never silently pruned. The shared document has a 450 KB safety limit; new changes remain pending with an explicit error if it fills. Export coach history saves the authoritative document plus pending changes without credentials. Full archive/restore management is a proposed next upgrade. PM5 raw samples are stored separately and are unaffected by the coaching limit. Personal raw data cannot be reconstructed if it was never received.

## Basis and limitations

NIDDK explains why the static 3,500-kcal rule is not a physiological forecast: https://www.niddk.nih.gov/health-information/professionals/diabetes-discoveries-practice/nih-body-weight-planner . The app's review is a bounded empirical starting aid, not that validated model.

HSS emphasizes adequate food/energy/protein for healing: https://www.hss.edu/health-library/conditions-and-treatments/nutrition-for-healing . Your care team sets fasting, postoperative nutrition and rehabilitation restrictions.

NIDDK habit guidance supports advance planning, progress tracking and returning after setbacks: https://www.niddk.nih.gov/health-information/diet-nutrition/changing-habits-better-health . This implementation is not a clinical-outcome validation.

Tests use real local HTTP/SQLite and Chromium plus a SQLite-backed D1 interface adapter, with simulated PM5 hardware, KV and cloud requests. No physical Pi/PM5/iOS WebKit, real Cloudflare deployment, home QR scan or ten-foot TV inspection is available here. Complete the physical acceptance checklist after installation.
