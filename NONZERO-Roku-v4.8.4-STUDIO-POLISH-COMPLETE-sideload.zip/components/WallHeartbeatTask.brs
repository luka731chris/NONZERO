sub init()
  m.top.functionName = "runHeartbeat"
  m.top.observeField("trigger","onTrigger")
end sub
sub onTrigger()
  m.top.control="RUN"
end sub
sub runHeartbeat()
  if m.top.endpoint="" or m.top.wallToken="" then return
  x=CreateObject("roUrlTransfer")
  x.SetUrl(m.top.endpoint + "/wall/heartbeat")
  x.SetCertificatesFile("common:/certs/ca-bundle.crt")
  x.InitClientCertificates()
  x.AddHeader("Content-Type","application/json")
  x.AddHeader("X-NONZERO-Wall",m.top.wallToken)
  rsp=x.PostFromString(FormatJson(m.top.payload))
  m.top.result={ok:(x.GetResponseCode()>=200 and x.GetResponseCode()<300),code:x.GetResponseCode()}
end sub
