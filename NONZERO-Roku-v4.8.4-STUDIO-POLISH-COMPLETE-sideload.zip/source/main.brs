sub Main()
    showNonzeroWall(false)
end sub

sub RunScreenSaver()
    showNonzeroWall(true)
end sub

sub showNonzeroWall(isScreensaver as Boolean)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    scene = screen.CreateScene("NonzeroWallScene")
    scene.isScreensaver = isScreensaver
    scene.observeField("quoteAction", port)
    screen.Show()

    clockNode = scene.findNode("clock")
    dateNode = scene.findNode("date")
    quoteNode = scene.findNode("ambientQuote")
    quoteAuthorNode = scene.findNode("ambientQuoteAuthor")
    quoteNodeB = scene.findNode("ambientQuoteB")
    quoteAuthorNodeB = scene.findNode("ambientQuoteAuthorB")
    quoteHintNode = scene.findNode("quoteFeedbackHint")
    quoteLayerA = scene.findNode("quoteLayerA")
    quoteLayerB = scene.findNode("quoteLayerB")
    quoteFadeAOut = scene.findNode("quoteFadeAOut")
    quoteFadeAIn = scene.findNode("quoteFadeAIn")
    quoteFadeBOut = scene.findNode("quoteFadeBOut")
    quoteFadeBIn = scene.findNode("quoteFadeBIn")
    cloudNode = scene.findNode("cloudStatus")

    quotes = buildQuoteLibrary()
    pref = CreateObject("roRegistrySection", "NONZERO_QUOTES_V4")
    deviceId = getQuoteDeviceId()
    appInfo = CreateObject("roAppInfo")
    quoteEndpoint = appInfo.GetValue("nonzero_worker_url")
    feedTask = createQuoteFeedTask(quoteEndpoint, deviceId, port)
    feedbackTasks = []
    seedClock = CreateObject("roDateTime")
    qSeed = seedClock.AsSeconds() mod 65536
    rotationCount = readInt(pref, "rotationCount", 0)
    recentIds = loadRecent(pref, "recentIds", 36)
    recentAuthors = loadRecent(pref, "recentAuthors", 10)
    recentDomains = loadRecent(pref, "recentDomains", 8)
    qIndex = chooseQuote(quotes, pref, qSeed, rotationCount, -1, recentIds, recentAuthors, recentDomains, scene.quoteContext)
    activeQuoteLayer = 0
    elapsed = 0
    forceRotate = false
    feedbackUntil = -1
    lastQuoteRotateElapsed = 0

    updateAmbientClock(clockNode, dateNode)
    scene.heartbeat = 1
    setInitialQuote(quotes[qIndex], quoteNode, quoteAuthorNode, quoteLayerA, quoteLayerB)
    recordExposure(pref, quotes[qIndex])
    pushRecent(recentIds, quotes[qIndex].id, 36)
    pushRecent(recentAuthors, quotes[qIndex].author, 10)
    pushRecent(recentDomains, quotes[qIndex].domain, 8)
    saveRecent(pref, "recentIds", recentIds)
    saveRecent(pref, "recentAuthors", recentAuthors)
    saveRecent(pref, "recentDomains", recentDomains)
    pref.Flush()

    if cloudNode <> invalid and cloudNode.text = "● CONNECTING" then cloudNode.text = "● LOCAL LIVE"

    while true
        msg = wait(1000, port)
        if type(msg) = "roSGScreenEvent" and msg.isScreenClosed() then return

        if type(msg) = "roSGNodeEvent" then
            if msg.GetField() = "result" then
                cloudResult = msg.GetData()
                if cloudResult <> invalid and cloudResult.quotes <> invalid and cloudResult.quotes.count() >= 20 then
                    quotes = cloudResult.quotes
                    qIndex = chooseQuote(quotes, pref, qSeed, rotationCount, -1, recentIds, recentAuthors, recentDomains, scene.quoteContext)
                    setInitialQuote(quotes[qIndex], quoteNode, quoteAuthorNode, quoteLayerA, quoteLayerB)
                    if quoteHintNode <> invalid then quoteHintNode.text = "CLOUD DISCOVERY LIVE · UP = MORE · DOWN = LESS · RIGHT = NEXT"
                end if
            else if msg.GetField() = "quoteAction" then
                action = msg.GetData()
                if action = "more" or action = "less" then
                    applyQuoteFeedback(pref, quotes[qIndex], action)
                    feedbackTasks.push(createCloudQuoteFeedbackTask(quoteEndpoint, deviceId, quotes[qIndex].id, action))
                    if quoteHintNode <> invalid then
                        if action = "more" then quoteHintNode.text = "SAVED: MORE LIKE THIS   |   LEARNING AUTHOR + THEMES + DOMAIN"
                        if action = "less" then quoteHintNode.text = "SAVED: LESS LIKE THIS   |   DIVERSIFYING THE NEXT PICKS"
                        quoteHintNode.color = "0xd58b38ff"
                    end if
                    feedbackUntil = elapsed + 4
                    forceRotate = true
                else if action = "next" then
                    feedbackTasks.push(createCloudQuoteFeedbackTask(quoteEndpoint, deviceId, quotes[qIndex].id, action))
                    if quoteHintNode <> invalid then quoteHintNode.text = "SKIPPED   |   FINDING A DIFFERENT VOICE"
                    feedbackUntil = elapsed + 3
                    forceRotate = true
                else if left(action, 7) = "rotate-" then
                    ' Automatic cadence: unique token guarantees a fresh SceneGraph event.
                    ' This is not negative/skip feedback.
                    forceRotate = true
                end if
            end if
        end if

        elapsed = elapsed + 1
        updateAmbientClock(clockNode, dateNode)
        scene.heartbeat = elapsed
        if scene.currentWallMode <> "deep" and elapsed > 0 and elapsed mod 1800 = 0 then
            feedTask = createQuoteFeedTask(quoteEndpoint, deviceId, port)
        end if
        if feedbackUntil >= 0 and elapsed >= feedbackUntil then
            if quoteHintNode <> invalid then
                quoteHintNode.text = "ROKU REMOTE: UP = MORE   |   DOWN = LESS   |   RIGHT = NEXT"
                quoteHintNode.color = "0x9aa8b4ff"
            end if
            feedbackUntil = -1
        end if

        ' v4.8.3: main loop owns quote cadence directly.
        ' SceneGraph timer is only a secondary nudge.
        quoteCadence = (elapsed - lastQuoteRotateElapsed >= 17)
        if scene.currentWallMode <> "deep" and (forceRotate or quoteCadence) then
            forceRotate = false
            lastQuoteRotateElapsed = elapsed
            qSeed = (qSeed * 25173 + 13849) mod 65536
            rotationCount = rotationCount + 1
            pref.Write("rotationCount", rotationCount.toStr())
            pref.Flush()

            nextIndex = chooseQuote(quotes, pref, qSeed, rotationCount, qIndex, recentIds, recentAuthors, recentDomains, scene.quoteContext)
            qIndex = nextIndex
            q = quotes[qIndex]
            recordExposure(pref, q)
            pushRecent(recentIds, q.id, 36)
            pushRecent(recentAuthors, q.author, 10)
            pushRecent(recentDomains, q.domain, 8)
            saveRecent(pref, "recentIds", recentIds)
            saveRecent(pref, "recentAuthors", recentAuthors)
            saveRecent(pref, "recentDomains", recentDomains)
            pref.Flush()

            ' v4.8.3 DIRECT QUOTE ENGINE
            ' Write every selected quote directly into the guaranteed-visible layer.
            if quoteNode <> invalid then quoteNode.text = q.text
            if quoteAuthorNode <> invalid then quoteAuthorNode.text = "— " + UCase(q.author) + "  ·  " + q.domain
            if quoteLayerA <> invalid then quoteLayerA.opacity = 1
            if quoteLayerB <> invalid then quoteLayerB.opacity = 0
            if quoteNodeB <> invalid then quoteNodeB.text = q.text
            if quoteAuthorNodeB <> invalid then quoteAuthorNodeB.text = "— " + UCase(q.author) + "  ·  " + q.domain
            activeQuoteLayer = 0
        end if
    end while
end sub

function getQuoteDeviceId() as String
    sec = CreateObject("roRegistrySection", "NONZERO_QUOTES_CLOUD")
    id = sec.Read("deviceId")
    if id = invalid or len(id) < 6 then
        dt = CreateObject("roDateTime")
        id = "roku" + dt.AsSeconds().toStr() + Rnd(999999).toStr()
        sec.Write("deviceId", id)
        sec.Flush()
    end if
    return id
end function

function createQuoteFeedTask(endpoint as String, deviceId as String, port as Object) as Object
    task = CreateObject("roSGNode", "QuoteTask")
    task.endpoint = endpoint
    task.deviceId = deviceId
    task.mode = "feed"
    task.observeField("result", port)
    task.control = "run"
    return task
end function

function createCloudQuoteFeedbackTask(endpoint as String, deviceId as String, quoteId as String, action as String) as Object
    task = CreateObject("roSGNode", "QuoteTask")
    task.endpoint = endpoint
    task.deviceId = deviceId
    task.mode = "feedback"
    task.quoteId = quoteId
    task.action = action
    task.control = "run"
    return task
end function

function buildQuoteLibrary() as Object
    ' v4.3.3: offline fallback corpus for cloud discovery. Broad multi-generation quote corpus. Real attributed voices dominate;
    ' NONZERO originals are intentionally sparse and used only as occasional filler.
    return [
        {id:"ma_right", text:"IF IT IS NOT RIGHT, DO NOT DO IT; IF IT IS NOT TRUE, DO NOT SAY IT.", author:"Marcus Aurelius", domain:"STOIC", tier:3, source:3, tags:["discipline","integrity","judgment"]},
        {id:"ma_be", text:"NO LONGER TALK AT ALL ABOUT THE KIND OF MAN THAT A GOOD MAN OUGHT TO BE, BUT BE SUCH.", author:"Marcus Aurelius", domain:"STOIC", tier:3, source:3, tags:["action","identity","integrity"]},
        {id:"ma_stand", text:"A MAN THEN MUST STAND ERECT, NOT BE KEPT ERECT BY OTHERS.", author:"Marcus Aurelius", domain:"STOIC", tier:3, source:3, tags:["resilience","ownership","strength"]},
        {id:"ma_duty", text:"I DO MY DUTY: OTHER THINGS TROUBLE ME NOT.", author:"Marcus Aurelius", domain:"STOIC", tier:3, source:3, tags:["focus","duty","composure"]},
        {id:"ma_change", text:"IF ANY MAN IS ABLE TO CONVINCE ME THAT I DO NOT ACT RIGHT, I WILL GLADLY CHANGE.", author:"Marcus Aurelius", domain:"STOIC", tier:3, source:3, tags:["learning","humility","growth"]},
        {id:"ma_river", text:"TIME IS LIKE A RIVER MADE UP OF THE EVENTS WHICH HAPPEN.", author:"Marcus Aurelius", domain:"STOIC", tier:3, source:3, tags:["time","perspective","wisdom"]},
        {id:"ma_wrestler", text:"THE ART OF LIFE IS MORE LIKE THE WRESTLER'S ART THAN THE DANCER'S.", author:"Marcus Aurelius", domain:"STOIC", tier:3, source:2, tags:["resilience","readiness","adaptability"]},
        {id:"epi_control", text:"SOME THINGS ARE IN OUR CONTROL AND OTHERS NOT.", author:"Epictetus", domain:"STOIC", tier:3, source:3, tags:["control","focus","composure"]},
        {id:"epi_exercise", text:"EXERCISE, THEREFORE, WHAT IS IN YOUR CONTROL.", author:"Epictetus", domain:"STOIC", tier:3, source:3, tags:["control","action","discipline"]},
        {id:"epi_first", text:"FIRST SAY TO YOURSELF WHAT YOU WOULD BE; AND THEN DO WHAT YOU HAVE TO DO.", author:"Epictetus", domain:"STOIC", tier:3, source:2, tags:["identity","action","purpose"]},
        {id:"epi_sudden", text:"NO GREAT THING IS CREATED SUDDENLY.", author:"Epictetus", domain:"STOIC", tier:3, source:2, tags:["patience","consistency","growth"]},
        {id:"epi_improve", text:"IF YOU WOULD IMPROVE, BE CONTENT TO BE THOUGHT FOOLISH AND STUPID.", author:"Epictetus", domain:"STOIC", tier:2, source:2, tags:["growth","humility","courage"]},
        {id:"epi_appearance", text:"YOU ARE BUT AN APPEARANCE, AND NOT ABSOLUTELY THE THING YOU APPEAR TO BE.", author:"Epictetus", domain:"STOIC", tier:2, source:3, tags:["perspective","composure","judgment"]},
        {id:"epi_prepare", text:"DO YOU NOT THINK THEN THAT I HAVE BEEN PREPARING FOR IT ALL MY LIFE?", author:"Epictetus", domain:"STOIC", tier:2, source:3, tags:["preparation","character","readiness"]},
        {id:"sen_time", text:"WHILE WE ARE POSTPONING, LIFE SPEEDS BY.", author:"Seneca", domain:"STOIC", tier:3, source:3, tags:["time","action","urgency"]},
        {id:"sen_hour", text:"HOLD EVERY HOUR IN YOUR GRASP.", author:"Seneca", domain:"STOIC", tier:3, source:3, tags:["time","focus","action"]},
        {id:"sen_waste", text:"IT IS NOT THAT WE HAVE A SHORT SPACE OF TIME, BUT THAT WE WASTE MUCH OF IT.", author:"Seneca", domain:"STOIC", tier:3, source:3, tags:["time","discipline","purpose"]},
        {id:"sen_today", text:"LAY HOLD OF TODAY'S TASK, AND YOU WILL NOT NEED TO DEPEND SO MUCH UPON TOMORROW'S.", author:"Seneca", domain:"STOIC", tier:3, source:3, tags:["action","preparation","focus"]},
        {id:"sen_study", text:"THERE IS NO TIME THAT IS UNSUITABLE FOR HELPFUL STUDIES.", author:"Seneca", domain:"STOIC", tier:2, source:3, tags:["learning","consistency","growth"]},
        {id:"sen_better", text:"I SHALL DEPART A BETTER MAN.", author:"Seneca", domain:"STOIC", tier:2, source:3, tags:["growth","character","purpose"]},
        {id:"socrates_examined", text:"THE UNEXAMINED LIFE IS NOT WORTH LIVING.", author:"Socrates", domain:"PHILOSOPHY", tier:2, source:2, tags:["reflection","wisdom","purpose"]},
        {id:"plato_start", text:"THE BEGINNING IS THE MOST IMPORTANT PART OF THE WORK.", author:"Plato", domain:"PHILOSOPHY", tier:2, source:1, tags:["start","action","momentum"]},
        {id:"aristotle_doing", text:"WE BECOME JUST BY DOING JUST ACTS, TEMPERATE BY DOING TEMPERATE ACTS, BRAVE BY DOING BRAVE ACTS.", author:"Aristotle", domain:"PHILOSOPHY", tier:2, source:2, tags:["habit","identity","action"]},
        {id:"conf_modest", text:"THE SUPERIOR MAN IS MODEST IN HIS SPEECH, BUT EXCEEDS IN HIS ACTIONS.", author:"Confucius", domain:"PHILOSOPHY", tier:2, source:2, tags:["action","humility","integrity"]},
        {id:"conf_worth", text:"WHEN WE SEE MEN OF WORTH, WE SHOULD THINK OF EQUALING THEM.", author:"Confucius", domain:"PHILOSOPHY", tier:2, source:2, tags:["growth","standards","learning"]},
        {id:"conf_courage", text:"TO SEE WHAT IS RIGHT AND NOT TO DO IT IS WANT OF COURAGE.", author:"Confucius", domain:"PHILOSOPHY", tier:2, source:2, tags:["courage","action","integrity"]},
        {id:"emerson_enthusiasm", text:"NOTHING GREAT WAS EVER ACHIEVED WITHOUT ENTHUSIASM.", author:"Ralph Waldo Emerson", domain:"WISDOM", tier:2, source:2, tags:["enthusiasm","achievement","energy"]},
        {id:"emerson_do", text:"DO THE THING, AND YOU WILL HAVE THE POWER.", author:"Ralph Waldo Emerson", domain:"WISDOM", tier:2, source:1, tags:["action","confidence","momentum"]},
        {id:"thoreau_direction", text:"GO CONFIDENTLY IN THE DIRECTION OF YOUR DREAMS. LIVE THE LIFE YOU HAVE IMAGINED.", author:"Henry David Thoreau", domain:"WISDOM", tier:2, source:1, tags:["confidence","purpose","action"]},
        {id:"douglass_struggle", text:"IF THERE IS NO STRUGGLE, THERE IS NO PROGRESS.", author:"Frederick Douglass", domain:"WISDOM", tier:2, source:3, tags:["resilience","progress","adversity"]},
        {id:"douglass_demand", text:"POWER CONCEDES NOTHING WITHOUT A DEMAND.", author:"Frederick Douglass", domain:"WISDOM", tier:1, source:3, tags:["courage","action","leadership"]},
        {id:"keller_optimism", text:"OPTIMISM IS THE FAITH THAT LEADS TO ACHIEVEMENT.", author:"Helen Keller", domain:"WISDOM", tier:2, source:2, tags:["optimism","achievement","mindset"]},
        {id:"keller_face", text:"KEEP YOUR FACE TO THE SUNSHINE AND YOU CANNOT SEE THE SHADOWS.", author:"Helen Keller", domain:"WISDOM", tier:1, source:1, tags:["optimism","perspective","mindset"]},
        {id:"edison_genius", text:"GENIUS IS ONE PERCENT INSPIRATION AND NINETY-NINE PERCENT PERSPIRATION.", author:"Thomas Edison", domain:"INNOVATION", tier:2, source:2, tags:["work","effort","execution"]},
        {id:"edison_work", text:"OPPORTUNITY IS MISSED BY MOST PEOPLE BECAUSE IT IS DRESSED IN OVERALLS AND LOOKS LIKE WORK.", author:"Thomas Edison", domain:"INNOVATION", tier:1, source:1, tags:["work","opportunity","effort"]},
        {id:"tr_arena", text:"THE CREDIT BELONGS TO THE MAN WHO IS ACTUALLY IN THE ARENA.", author:"Theodore Roosevelt", domain:"PUBLIC SERVICE", tier:3, source:3, tags:["courage","action","resilience"]},
        {id:"tr_work", text:"THE BEST PRIZE THAT LIFE OFFERS IS THE CHANCE TO WORK HARD AT WORK WORTH DOING.", author:"Theodore Roosevelt", domain:"PUBLIC SERVICE", tier:2, source:2, tags:["work","purpose","effort"]},
        {id:"tr_dare", text:"FAR BETTER IT IS TO DARE MIGHTY THINGS THAN TO RANK WITH THOSE POOR SPIRITS WHO NEITHER ENJOY NOR SUFFER MUCH.", author:"Theodore Roosevelt", domain:"PUBLIC SERVICE", tier:2, source:2, tags:["courage","risk","achievement"]},
        {id:"fdr_fear", text:"THE ONLY THING WE HAVE TO FEAR IS FEAR ITSELF.", author:"Franklin D. Roosevelt", domain:"PUBLIC SERVICE", tier:3, source:3, tags:["courage","composure","resilience"]},
        {id:"fdr_try", text:"ABOVE ALL, TRY SOMETHING.", author:"Franklin D. Roosevelt", domain:"PUBLIC SERVICE", tier:2, source:1, tags:["action","experimentation","courage"]},
        {id:"jfk_hard", text:"WE CHOOSE TO GO TO THE MOON, NOT BECAUSE IT IS EASY, BUT BECAUSE IT IS HARD.", author:"John F. Kennedy", domain:"PUBLIC SERVICE", tier:3, source:3, tags:["challenge","courage","achievement"]},
        {id:"jfk_direction", text:"EFFORTS AND COURAGE ARE NOT ENOUGH WITHOUT PURPOSE AND DIRECTION.", author:"John F. Kennedy", domain:"PUBLIC SERVICE", tier:2, source:2, tags:["purpose","direction","courage"]},
        {id:"ike_planning", text:"PLANS ARE WORTHLESS, BUT PLANNING IS EVERYTHING.", author:"Dwight Eisenhower", domain:"PUBLIC SERVICE", tier:3, source:3, tags:["preparation","adaptability","leadership"]},
        {id:"ike_prepare", text:"IN PREPARING FOR BATTLE I HAVE ALWAYS FOUND THAT PLANS ARE USELESS, BUT PLANNING IS INDISPENSABLE.", author:"Dwight Eisenhower", domain:"PUBLIC SERVICE", tier:3, source:2, tags:["preparation","adaptability","leadership"]},
        {id:"powell_optimism", text:"PERPETUAL OPTIMISM IS A FORCE MULTIPLIER.", author:"Colin Powell", domain:"PUBLIC SERVICE", tier:3, source:3, tags:["optimism","leadership","resilience"]},
        {id:"powell_calm", text:"REMAIN CALM. BE KIND.", author:"Colin Powell", domain:"PUBLIC SERVICE", tier:3, source:3, tags:["composure","kindness","leadership"]},
        {id:"powell_work", text:"A DREAM DOESN'T BECOME REALITY THROUGH MAGIC; IT TAKES SWEAT, DETERMINATION AND HARD WORK.", author:"Colin Powell", domain:"PUBLIC SERVICE", tier:2, source:2, tags:["work","determination","execution"]},
        {id:"reagan_verify", text:"TRUST, BUT VERIFY.", author:"Ronald Reagan", domain:"PUBLIC SERVICE", tier:3, source:3, tags:["judgment","standards","leadership"]},
        {id:"goggins_done", text:"DON'T STOP WHEN YOU'RE TIRED. STOP WHEN YOU'RE DONE.", author:"David Goggins", domain:"ENDURANCE", tier:3, source:3, tags:["discipline","endurance","execution","resilience"]},
        {id:"goggins_uncommon", text:"BE UNCOMMON AMONG UNCOMMON PEOPLE.", author:"David Goggins", domain:"ENDURANCE", tier:3, source:2, tags:["standards","identity","competition"]},
        {id:"jocko_freedom", text:"DISCIPLINE EQUALS FREEDOM.", author:"Jocko Willink", domain:"MILITARY", tier:3, source:3, tags:["discipline","ownership","execution"]},
        {id:"jocko_excuses", text:"STOP. MAKING. EXCUSES. TAKE ACTION. OWN YOUR DECISIONS. EXECUTE.", author:"Jocko Willink", domain:"MILITARY", tier:3, source:3, tags:["ownership","execution","discipline"]},
        {id:"jocko_good", text:"GOOD.", author:"Jocko Willink", domain:"MILITARY", tier:2, source:2, tags:["resilience","reframe","composure"]},
        {id:"mcraven_bed", text:"IF YOU WANT TO CHANGE THE WORLD, START OFF BY MAKING YOUR BED.", author:"Adm. William McRaven", domain:"MILITARY", tier:3, source:3, tags:["discipline","standards","momentum"]},
        {id:"mcraven_little", text:"IF YOU CAN'T DO THE LITTLE THINGS RIGHT, YOU WILL NEVER DO THE BIG THINGS RIGHT.", author:"Adm. William McRaven", domain:"MILITARY", tier:3, source:3, tags:["standards","details","discipline"]},
        {id:"mcraven_bell", text:"IF YOU WANT TO CHANGE THE WORLD, NEVER EVER RING THE BELL.", author:"Adm. William McRaven", domain:"MILITARY", tier:3, source:3, tags:["resilience","endurance","courage"]},
        {id:"seal_never", text:"I WILL NEVER QUIT. I PERSEVERE AND THRIVE ON ADVERSITY.", author:"U.S. Navy SEAL Ethos", domain:"MILITARY", tier:3, source:2, tags:["resilience","adversity","team"]},
        {id:"kranz_tough", text:"TOUGH AND COMPETENT.", author:"Gene Kranz", domain:"SPACE", tier:3, source:3, tags:["standards","competence","resilience"]},
        {id:"kranz_risk", text:"THERE IS NO ACHIEVEMENT WITHOUT RISK.", author:"Gene Kranz", domain:"SPACE", tier:3, source:3, tags:["courage","risk","achievement"]},
        {id:"kranz_believe", text:"YOU HAVE GOT TO BELIEVE IT. YOUR TEAM MUST BELIEVE IT, AND WE MUST MAKE IT HAPPEN.", author:"Gene Kranz", domain:"SPACE", tier:3, source:3, tags:["belief","team","execution"]},
        {id:"earhart_prepare", text:"PREPARATION, I HAVE OFTEN SAID, IS RIGHTLY TWO-THIRDS OF ANY VENTURE.", author:"Amelia Earhart", domain:"EXPLORATION", tier:2, source:1, tags:["preparation","risk","readiness"]},
        {id:"tomlin_standard", text:"THE STANDARD IS THE STANDARD.", author:"Mike Tomlin", domain:"SPORTS", tier:3, source:3, tags:["standards","consistency","execution"]},
        {id:"tomlin_opportunity", text:"I DON'T WORRY ABOUT THE LIMITS. I JUST WORK WITH THE OPPORTUNITY GIVEN.", author:"Mike Tomlin", domain:"SPORTS", tier:3, source:3, tags:["adaptability","execution","focus"]},
        {id:"tomlin_humble", text:"WE STAY HUMBLE IN TIMES OF EXCELLENCE.", author:"Mike Tomlin", domain:"SPORTS", tier:3, source:3, tags:["humility","excellence","mindset"]},
        {id:"tomlin_fears", text:"WE DON'T LIVE IN OUR FEARS.", author:"Mike Tomlin", domain:"SPORTS", tier:3, source:2, tags:["courage","composure","mindset"]},
        {id:"brady_earn", text:"YOU NEED TO EARN IT EVERY DAY.", author:"Tom Brady", domain:"SPORTS", tier:3, source:3, tags:["consistency","competition","work"]},
        {id:"brady_prepare", text:"CONFIDENCE DOES COME FROM PREPARATION AND SOLID PREPARATION IN PRACTICE.", author:"Tom Brady", domain:"SPORTS", tier:3, source:3, tags:["preparation","confidence","practice"]},
        {id:"brady_outprepare", text:"WE'RE GOING TO TRY TO OUT-PREPARE THEM THIS WEEK.", author:"Tom Brady", domain:"SPORTS", tier:3, source:3, tags:["preparation","competition","execution"]},
        {id:"brady_bottom", text:"EVERY TEAM STARTS AT THE BOTTOM EVERY YEAR.", author:"Tom Brady", domain:"SPORTS", tier:2, source:3, tags:["reset","humility","competition"]},
        {id:"belichick_prep", text:"PRACTICE IS JUST PREPARATION. IT'S NOT PUNISHMENT. IT'S PREPARATION.", author:"Bill Belichick", domain:"SPORTS", tier:3, source:3, tags:["preparation","practice","mindset"]},
        {id:"belichick_discipline", text:"DISCIPLINE IS, WHEN THE BALL IS SNAPPED, DOING YOUR JOB.", author:"Bill Belichick", domain:"SPORTS", tier:3, source:3, tags:["discipline","execution","role"]},
        {id:"belichick_job", text:"EACH OF US HAS A JOB TO DO.", author:"Bill Belichick", domain:"SPORTS", tier:3, source:3, tags:["role","team","execution"]},
        {id:"belichick_control", text:"WE TRY TO CONTROL OUR PREPARATION AND PERFORMANCE.", author:"Bill Belichick", domain:"SPORTS", tier:3, source:3, tags:["control","preparation","performance"]},
        {id:"saban_process", text:"IT'S THE PROCESS OF WHAT IT TAKES TO DO IT RIGHT SO YOU HAVE THE BEST CHANCE TO GET IT RIGHT.", author:"Nick Saban", domain:"SPORTS", tier:3, source:3, tags:["process","preparation","standards"]},
        {id:"saban_price", text:"THE PRICE FOR SUCCESS HAS TO BE PAID UP FRONT.", author:"Nick Saban", domain:"SPORTS", tier:3, source:3, tags:["work","preparation","success"]},
        {id:"saban_discipline", text:"FOCUS, CONCENTRATE AND MAINTAIN OUR DISCIPLINE.", author:"Nick Saban", domain:"SPORTS", tier:3, source:3, tags:["focus","discipline","consistency"]},
        {id:"saban_hard", text:"TO ESTABLISH MENTAL TOUGHNESS, THINGS HAVE TO BE DIFFICULT.", author:"Nick Saban", domain:"SPORTS", tier:3, source:3, tags:["toughness","adversity","growth"]},
        {id:"wooden_success", text:"SUCCESS IS PEACE OF MIND FROM KNOWING YOU MADE THE EFFORT TO BECOME THE BEST YOU ARE CAPABLE OF BECOMING.", author:"John Wooden", domain:"SPORTS", tier:3, source:3, tags:["effort","standards","peace"]},
        {id:"wooden_best", text:"PERFORM AT YOUR BEST ABILITY WHEN YOUR BEST IS REQUIRED.", author:"John Wooden", domain:"SPORTS", tier:3, source:3, tags:["performance","readiness","excellence"]},
        {id:"wooden_scoreboard", text:"DON'T LOOK AT THE SCOREBOARD.", author:"John Wooden", domain:"SPORTS", tier:2, source:3, tags:["process","focus","control"]},
        {id:"wooden_industrious", text:"INDUSTRIOUSNESS, SELF-CONTROL, INITIATIVE, INTENTNESS.", author:"John Wooden", domain:"SPORTS", tier:2, source:3, tags:["work","control","initiative"]},
        {id:"summitt_respect", text:"RESPECT YOURSELF AND OTHERS.", author:"Pat Summitt", domain:"SPORTS", tier:3, source:3, tags:["respect","leadership","character"]},
        {id:"summitt_responsibility", text:"TAKE FULL RESPONSIBILITY.", author:"Pat Summitt", domain:"SPORTS", tier:3, source:3, tags:["ownership","leadership","character"]},
        {id:"summitt_discipline", text:"DISCIPLINE YOURSELF SO NO ONE ELSE HAS TO.", author:"Pat Summitt", domain:"SPORTS", tier:3, source:3, tags:["discipline","ownership","standards"]},
        {id:"summitt_passion", text:"MAKE HARD WORK YOUR PASSION.", author:"Pat Summitt", domain:"SPORTS", tier:3, source:3, tags:["work","passion","effort"]},
        {id:"summitt_success", text:"HANDLE SUCCESS LIKE YOU HANDLE FAILURE.", author:"Pat Summitt", domain:"SPORTS", tier:3, source:3, tags:["composure","success","resilience"]},
        {id:"kobe_obsession", text:"WE'RE BOTH CURSED WITH THE OBSESSION OF TRYING TO BE THE BEST THAT WE CAN.", author:"Kobe Bryant", domain:"SPORTS", tier:2, source:3, tags:["competition","standards","obsession"]},
        {id:"kobe_advice", text:"I WOULD ASK FOR ADVICE, AND HE WOULD GIVE ME ADVICE STRAIGHT FROM HIS HEART.", author:"Kobe Bryant", domain:"SPORTS", tier:1, source:3, tags:["learning","humility","growth"]},
        {id:"jordan_failure", text:"I'VE FAILED OVER AND OVER AND OVER AGAIN IN MY LIFE. AND THAT IS WHY I SUCCEED.", author:"Michael Jordan", domain:"SPORTS", tier:2, source:1, tags:["failure","resilience","success"]},
        {id:"ali_days", text:"DON'T COUNT THE DAYS; MAKE THE DAYS COUNT.", author:"Muhammad Ali", domain:"SPORTS", tier:2, source:1, tags:["time","action","purpose"]},
        {id:"ali_training", text:"I HATED EVERY MINUTE OF TRAINING, BUT I SAID, DO NOT QUIT.", author:"Muhammad Ali", domain:"SPORTS", tier:2, source:1, tags:["training","resilience","discipline"]},
        {id:"duckworth_grit", text:"GRIT IS LIVING LIFE LIKE IT'S A MARATHON, NOT A SPRINT.", author:"Angela Duckworth", domain:"PSYCHOLOGY", tier:3, source:3, tags:["grit","endurance","consistency"]},
        {id:"duckworth_endurance", text:"ENTHUSIASM IS COMMON. ENDURANCE IS RARE.", author:"Angela Duckworth", domain:"PSYCHOLOGY", tier:3, source:2, tags:["endurance","consistency","enthusiasm"]},
        {id:"duckworth_effort", text:"EFFORT COUNTS TWICE.", author:"Angela Duckworth", domain:"PSYCHOLOGY", tier:3, source:2, tags:["effort","grit","performance"]},
        {id:"dweck_becoming", text:"BECOMING IS BETTER THAN BEING.", author:"Carol Dweck", domain:"PSYCHOLOGY", tier:2, source:2, tags:["growth","identity","learning"]},
        {id:"dweck_yet", text:"THE POWER OF YET.", author:"Carol Dweck", domain:"PSYCHOLOGY", tier:2, source:2, tags:["growth","optimism","learning"]},
        {id:"fogg_good", text:"PEOPLE CHANGE BEST BY FEELING GOOD, NOT BY FEELING BAD.", author:"BJ Fogg", domain:"BEHAVIOR", tier:2, source:2, tags:["behavior","positive","change"]},
        {id:"fogg_small", text:"TINY IS MIGHTY.", author:"BJ Fogg", domain:"BEHAVIOR", tier:2, source:2, tags:["behavior","momentum","consistency"]},
        {id:"clear_systems", text:"YOU DO NOT RISE TO THE LEVEL OF YOUR GOALS. YOU FALL TO THE LEVEL OF YOUR SYSTEMS.", author:"James Clear", domain:"BEHAVIOR", tier:2, source:2, tags:["systems","habit","consistency"]},
        {id:"clear_votes", text:"EVERY ACTION YOU TAKE IS A VOTE FOR THE TYPE OF PERSON YOU WISH TO BECOME.", author:"James Clear", domain:"BEHAVIOR", tier:2, source:2, tags:["identity","habit","action"]},
        {id:"loehr_energy", text:"ENERGY, NOT TIME, IS THE FUNDAMENTAL CURRENCY OF HIGH PERFORMANCE.", author:"Jim Loehr", domain:"PSYCHOLOGY", tier:3, source:2, tags:["energy","performance","recovery"]},
        {id:"loehr_ritual", text:"THE POWER OF RITUALS IS THAT THEY INSURE THE LEAST POSSIBLE EXPENDITURE OF CONSCIOUS ENERGY.", author:"Jim Loehr", domain:"PSYCHOLOGY", tier:2, source:1, tags:["ritual","energy","consistency"]},
        {id:"gervais_train", text:"THERE ARE ONLY THREE THINGS WE CAN TRAIN: OUR CRAFT, OUR BODY, AND OUR MIND.", author:"Michael Gervais", domain:"PSYCHOLOGY", tier:3, source:2, tags:["mindset","practice","performance"]},
        {id:"gervais_present", text:"THE PRESENT MOMENT IS WHERE HIGH PERFORMANCE HAPPENS.", author:"Michael Gervais", domain:"PSYCHOLOGY", tier:2, source:1, tags:["focus","presence","performance"]},
        {id:"frankl_change", text:"WHEN WE ARE NO LONGER ABLE TO CHANGE A SITUATION, WE ARE CHALLENGED TO CHANGE OURSELVES.", author:"Viktor Frankl", domain:"PSYCHOLOGY", tier:2, source:1, tags:["adaptability","resilience","growth"]},
        {id:"frankl_why", text:"THOSE WHO HAVE A WHY TO LIVE CAN BEAR WITH ALMOST ANY HOW.", author:"Viktor Frankl", domain:"PSYCHOLOGY", tier:2, source:1, tags:["purpose","resilience","meaning"]},
        {id:"jobs_time", text:"YOUR TIME IS LIMITED, SO DON'T WASTE IT LIVING SOMEONE ELSE'S LIFE.", author:"Steve Jobs", domain:"BUSINESS", tier:3, source:3, tags:["time","purpose","courage"]},
        {id:"jobs_voice", text:"DON'T LET THE NOISE OF OTHERS' OPINIONS DROWN OUT YOUR OWN INNER VOICE.", author:"Steve Jobs", domain:"BUSINESS", tier:3, source:3, tags:["focus","courage","purpose"]},
        {id:"bezos_long", text:"IT IS ALL ABOUT THE LONG TERM.", author:"Jeff Bezos", domain:"BUSINESS", tier:3, source:3, tags:["longterm","patience","strategy"]},
        {id:"bezos_focus", text:"WE WILL CONTINUE TO FOCUS RELENTLESSLY ON OUR CUSTOMERS.", author:"Jeff Bezos", domain:"BUSINESS", tier:3, source:3, tags:["focus","customer","consistency"]},
        {id:"bezos_velocity", text:"HIGH-VELOCITY DECISION MAKING.", author:"Jeff Bezos", domain:"BUSINESS", tier:3, source:3, tags:["decision","speed","execution"]},
        {id:"bezos_trust", text:"YOU EARN TRUST SLOWLY, OVER TIME, BY DOING HARD THINGS WELL.", author:"Jeff Bezos", domain:"BUSINESS", tier:3, source:3, tags:["trust","standards","consistency"]},
        {id:"nadella_learn", text:"THE LEARN-IT-ALL DOES BETTER THAN THE KNOW-IT-ALL.", author:"Satya Nadella", domain:"BUSINESS", tier:3, source:3, tags:["learning","humility","growth"]},
        {id:"nadella_growth", text:"KEEP BUILDING OUR KNOWLEDGE AND LOSE OUR FEAR OF FAILURE.", author:"Satya Nadella", domain:"BUSINESS", tier:2, source:3, tags:["learning","failure","growth"]},
        {id:"buffett_reputation", text:"WE CAN AFFORD TO LOSE MONEY, EVEN A LOT OF MONEY. BUT WE CANNOT AFFORD TO LOSE REPUTATION.", author:"Warren Buffett", domain:"BUSINESS", tier:2, source:2, tags:["reputation","integrity","standards"]},
        {id:"buffett_habits", text:"CHAINS OF HABIT ARE TOO LIGHT TO BE FELT UNTIL THEY ARE TOO HEAVY TO BE BROKEN.", author:"Warren Buffett", domain:"BUSINESS", tier:2, source:1, tags:["habit","discipline","behavior"]},
        {id:"buffett_circle", text:"KNOW YOUR CIRCLE OF COMPETENCE AND STICK WITHIN IT.", author:"Warren Buffett", domain:"BUSINESS", tier:2, source:1, tags:["competence","focus","judgment"]},
        {id:"munger_simple", text:"TAKE A SIMPLE IDEA AND TAKE IT SERIOUSLY.", author:"Charlie Munger", domain:"BUSINESS", tier:2, source:1, tags:["focus","simplicity","execution"]},
        {id:"munger_learning", text:"GO TO BED SMARTER THAN WHEN YOU WOKE UP.", author:"Charlie Munger", domain:"BUSINESS", tier:2, source:1, tags:["learning","consistency","growth"]},
        {id:"rogers_helpers", text:"LOOK FOR THE HELPERS. YOU WILL ALWAYS FIND PEOPLE WHO ARE HELPING.", author:"Fred Rogers", domain:"SUPPORT", tier:1, source:2, tags:["support","optimism","community"]},
        {id:"rogers_feelings", text:"ANYTHING THAT IS HUMAN IS MENTIONABLE, AND ANYTHING THAT IS MENTIONABLE CAN BE MORE MANAGEABLE.", author:"Fred Rogers", domain:"SUPPORT", tier:1, source:2, tags:["support","emotion","resilience"]},
        {id:"angelou_do", text:"DO THE BEST YOU CAN UNTIL YOU KNOW BETTER. THEN WHEN YOU KNOW BETTER, DO BETTER.", author:"Maya Angelou", domain:"SUPPORT", tier:1, source:1, tags:["growth","learning","kindness"]},
        {id:"serena_belief", text:"YOU HAVE TO BELIEVE IN YOURSELF WHEN NO ONE ELSE DOES.", author:"Serena Williams", domain:"SPORTS", tier:2, source:1, tags:["belief","confidence","resilience"]},
        {id:"serena_champion", text:"A CHAMPION IS DEFINED NOT BY THEIR WINS BUT BY HOW THEY CAN RECOVER WHEN THEY FALL.", author:"Serena Williams", domain:"SPORTS", tier:2, source:1, tags:["recovery","resilience","competition"]},
        {id:"nz_zero", text:"ZERO IS THE ONLY MISS.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["consistency","action"]},
        {id:"nz_ten", text:"TEN MINUTES BEATS ZERO.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["consistency","momentum"]},
        {id:"nz_board", text:"SHOW UP. PUT A NUMBER ON THE BOARD.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["action","consistency"]},
        {id:"nz_identity", text:"MAKE CONSISTENCY THE IDENTITY AND INTENSITY THE VARIABLE.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["consistency","identity","adaptability"]},
        {id:"nz_shrink", text:"WHEN RESISTANCE IS HIGH, SHRINK THE TASK INSTEAD OF DELETING IT.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["momentum","adaptability","resilience"]},
        {id:"nz_evidence", text:"YOUR FUTURE SELF NEEDS EVIDENCE, NOT ANOTHER INTENTION.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["action","identity","execution"]},
        {id:"nz_firstfive", text:"USE THE FIRST FIVE MINUTES TO DEFEAT THE FIRST EXCUSE.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["start","momentum","discipline"]},
        {id:"nz_next", text:"PROTECT THE NEXT GOOD CHOICE BEFORE MOTIVATION ARRIVES.", author:"NONZERO", domain:"NONZERO", tier:0, source:0, tags:["behavior","preparation","consistency"]}
    ]
end function

function chooseQuote(quotes as Object, pref as Object, seed as Integer, rotationCount as Integer, currentIndex as Integer, recentIds as Object, recentAuthors as Object, recentDomains as Object, context as String) as Integer
    ' Taste engine: 73% preference-driven, 20% discovery, ~7% NONZERO original.
    ' Hard quote-recency plus author/domain diversity prevents the former 4-5 quote loop.
    mode = (rotationCount + 1) mod 15
    wantBrand = (mode = 0)
    discovery = (mode = 2 or mode = 6 or mode = 10)

    bestScore = -999999
    scored = []
    for i = 0 to quotes.count() - 1
        q = quotes[i]
        isBrand = (q.domain = "NONZERO")
        if isBrand = wantBrand and i <> currentIndex and not containsText(recentIds, q.id) then
            s = scoreQuote(q, pref, seed, i, recentIds, recentAuthors, recentDomains, discovery, context)
            scored.push({idx:i, score:s})
            if s > bestScore then bestScore = s
        end if
    end for

    ' Choose from a competitive top band rather than always taking one deterministic winner.
    ' This preserves taste while allowing genuine variety among similarly relevant quotes.
    finalists = []
    band = 34
    if discovery then band = 52
    for each item in scored
        if item.score >= bestScore - band then finalists.push(item.idx)
    end for
    if finalists.count() > 0 then return finalists[seed mod finalists.count()]

    ' Safety fallback if every quote in the target pool is inside the persisted recency window.
    fallback = []
    for i = 0 to quotes.count() - 1
        q = quotes[i]
        if (q.domain = "NONZERO") = wantBrand and i <> currentIndex then fallback.push(i)
    end for
    if fallback.count() > 0 then return fallback[seed mod fallback.count()]
    return 0
end function

function scoreQuote(q as Object, pref as Object, seed as Integer, index as Integer, recentIds as Object, recentAuthors as Object, recentDomains as Object, discovery as Boolean, context as String) as Integer
    exposure = readInt(pref, "exp_" + q.id, 0)
    if exposure > 60 then exposure = 60
    quoteTaste = readInt(pref, "quote_" + q.id, 0)

    if discovery then
        ' Discovery favors high-integrity sources, lightly exposed authors, and new domains.
        score = 110 + (q.source * 11) + (q.tier * 3)
        score = score - (exposure * 13)
        score = score + (domainWeight(pref, q.domain) * 2)
        for each tag in q.tags
            score = score + (tagWeight(pref, tag) * 2)
        end for
    else
        score = 100 + (q.source * 9) + (q.tier * 6)
        score = score + (domainWeight(pref, q.domain) * 8)
        score = score + (authorWeight(pref, q.author, q.tier) * 9)
        score = score + (quoteTaste * 12)
        for each tag in q.tags
            score = score + (tagWeight(pref, tag) * 7)
        end for
        score = score - (exposure * 5)
    end if

    ' Author recency is deliberately strong. You should almost never see the same person twice
    ' v4.3.5 dynamic quote architecture: after today's workout is complete,
    ' skew toward earned accomplishment + future consistency without creating
    ' a repetitive victory-only loop. Before completion, retain standard motivation.
    if context = "accomplishment" then
        if q.tags <> invalid then
            for each tag in q.tags
                t = lcase(tag.toStr())
                if t = "achievement" or t = "success" or t = "progress" then score = score + 115
                if t = "consistency" or t = "habit" or t = "identity" or t = "longterm" then score = score + 100
                if t = "effort" or t = "discipline" or t = "momentum" or t = "character" then score = score + 70
                if t = "recovery" or t = "reflection" or t = "humility" then score = score + 38
                if t = "start" or t = "failure" or t = "reset" then score = score - 62
            end for
        end if
    end if

    ' inside the next 10 quote rotations, even when that author is highly up-voted.
    if containsText(recentAuthors, q.author) then score = score - 420
    if recentDomains.count() > 0 and recentDomains[recentDomains.count()-1] = q.domain then score = score - 85
    if recentDomains.count() >= 2 and recentDomains[recentDomains.count()-2] = q.domain then score = score - 35

    ' Larger pseudo-random jitter solves deterministic clustering while keeping affinity dominant.
    score = score + ((seed + index * 83 + exposure * 17) mod 47)
    return score
end function

sub applyQuoteFeedback(pref as Object, q as Object, action as String)
    delta = 1
    if action = "less" then delta = -1
    changeWeight(pref, "quote_" + q.id, delta * 3, -12, 18)
    changeWeight(pref, "author_" + safeKey(q.author), delta * 2, -10, 14)
    changeWeight(pref, "domain_" + safeKey(q.domain), delta, -8, 12)
    for each tag in q.tags
        changeWeight(pref, "tag_" + safeKey(tag), delta, -8, 12)
    end for
    if q.tier = 1 then changeWeight(pref, "discoveryAffinity", delta, -6, 10)
    pref.Flush()
end sub

sub recordExposure(pref as Object, q as Object)
    k = "exp_" + q.id
    n = readInt(pref, k, 0) + 1
    if n > 999 then n = 999
    pref.Write(k, n.toStr())
end sub

function tagWeight(pref as Object, tag as String) as Integer
    k = "tag_" + safeKey(tag)
    stored = pref.Read(k)
    if stored <> invalid and stored <> "" then return int(val(stored))
    defaults = {discipline:6, execution:6, preparation:6, standards:6, resilience:6, focus:6, ownership:5, courage:5, consistency:6, mindset:5, confidence:4, leadership:4, recovery:3, learning:4, adaptability:4, team:3, risk:3, innovation:3, integrity:5, action:6, momentum:5, endurance:5, details:4, competence:4, optimism:4, judgment:4, growth:4, effort:5, practice:5, grit:5, adversity:5, work:5, achievement:4, initiative:4, humility:3, purpose:5, identity:4, role:3, energy:3, performance:5, competition:4, control:5, time:4, perspective:4, wisdom:4, habit:5, behavior:5, process:5, toughness:5, excellence:5, respect:4, kindness:3, support:3, challenge:4, direction:4, trust:4, longterm:3, decision:3, speed:3, customer:2, belief:4, reframe:4, presence:4, meaning:4, peace:3, obsession:4, training:5, success:4, failure:4, reset:3, start:6, experimentation:3, opportunity:4, reputation:4, simplicity:4, emotion:3, community:3, passion:4, strategy:3, determination:5, readiness:5, reflection:3, character:4, duty:4, strength:4, progress:4, change:4}
    if defaults[tag] <> invalid then return defaults[tag]
    return 2
end function

function domainWeight(pref as Object, domain as String) as Integer
    k = "domain_" + safeKey(domain)
    stored = pref.Read(k)
    if stored <> invalid and stored <> "" then return int(val(stored))
    if domain = "PUBLIC SERVICE" then return 4
    defaults = {STOIC:6, SPORTS:6, PSYCHOLOGY:6, BEHAVIOR:6, MILITARY:6, ENDURANCE:6, SPACE:5, BUSINESS:4, PHILOSOPHY:5, WISDOM:4, INNOVATION:4, EXPLORATION:4, SUPPORT:4, NONZERO:2}
    if defaults[domain] <> invalid then return defaults[domain]
    return 3
end function

function authorWeight(pref as Object, author as String, tier as Integer) as Integer
    k = "author_" + safeKey(author)
    stored = pref.Read(k)
    if stored <> invalid and stored <> "" then return int(val(stored))
    if tier = 3 then return 3
    if tier = 2 then return 1
    return 0
end function

sub changeWeight(pref as Object, key as String, delta as Integer, low as Integer, high as Integer)
    n = readInt(pref, key, 0) + delta
    if n < low then n = low
    if n > high then n = high
    pref.Write(key, n.toStr())
end sub

function readInt(pref as Object, key as String, fallback as Integer) as Integer
    v = pref.Read(key)
    if v = invalid or v = "" then return fallback
    return int(val(v))
end function

function safeKey(s as String) as String
    src = LCase(s)
    out = ""
    for i = 1 to len(src)
        c = mid(src, i, 1)
        if (c >= "a" and c <= "z") or (c >= "0" and c <= "9") then
            out = out + c
        else if c = " " or c = "-" then
            out = out + "_"
        end if
    end for
    return out
end function

function containsText(items as Object, value as String) as Boolean
    for each item in items
        if item = value then return true
    end for
    return false
end function

sub pushRecent(items as Object, value as String, maxCount as Integer)
    items.push(value)
    while items.count() > maxCount
        items.shift()
    end while
end sub

function loadRecent(pref as Object, key as String, maxCount as Integer) as Object
    out = []
    raw = pref.Read(key)
    if raw <> invalid and raw <> "" then
        parts = raw.Tokenize("|")
        for each p in parts
            if p <> "" then out.push(p)
        end for
    end if
    while out.count() > maxCount
        out.shift()
    end while
    return out
end function

sub saveRecent(pref as Object, key as String, items as Object)
    raw = ""
    for each item in items
        if raw <> "" then raw = raw + "|"
        raw = raw + item
    end for
    pref.Write(key, raw)
end sub

sub setInitialQuote(q as Object, quoteNode as Object, authorNode as Object, layerA as Object, layerB as Object)
    if quoteNode <> invalid then quoteNode.text = q.text
    if authorNode <> invalid then authorNode.text = "— " + UCase(q.author) + "  ·  " + q.domain
    if layerA <> invalid then layerA.opacity = 1
    if layerB <> invalid then layerB.opacity = 0
end sub

sub updateAmbientClock(clockNode as Object, dateNode as Object)
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    h = dt.GetHours()
    mins = dt.GetMinutes()
    suffix = "AM"
    displayH = h
    if h >= 12 then suffix = "PM"
    if displayH = 0 then displayH = 12
    if displayH > 12 then displayH = displayH - 12
    mm = mins.toStr()
    if mins < 10 then mm = "0" + mm
    if clockNode <> invalid then clockNode.text = displayH.toStr() + ":" + mm + " " + suffix
    if dateNode <> invalid then dateNode.text = dt.GetMonth().toStr() + "/" + dt.GetDayOfMonth().toStr() + "/" + dt.GetYear().toStr()
end sub
